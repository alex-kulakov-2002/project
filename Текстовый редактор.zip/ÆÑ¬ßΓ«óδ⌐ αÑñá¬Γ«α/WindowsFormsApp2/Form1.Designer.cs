﻿namespace WindowsFormsApp2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.Fail = new System.Windows.Forms.ToolStripMenuItem();
            this.Open = new System.Windows.Forms.ToolStripMenuItem();
            this.SaveAs = new System.Windows.Forms.ToolStripMenuItem();
            this.Save = new System.Windows.Forms.ToolStripMenuItem();
            this.NewWindow = new System.Windows.Forms.ToolStripMenuItem();
            this.Edit = new System.Windows.Forms.ToolStripMenuItem();
            this.SelectAllTextEdit = new System.Windows.Forms.ToolStripMenuItem();
            this.CopyEdit = new System.Windows.Forms.ToolStripMenuItem();
            this.PasteEdit = new System.Windows.Forms.ToolStripMenuItem();
            this.CutEdit = new System.Windows.Forms.ToolStripMenuItem();
            this.FormatEdit = new System.Windows.Forms.ToolStripMenuItem();
            this.Format = new System.Windows.Forms.ToolStripMenuItem();
            this.Options = new System.Windows.Forms.ToolStripMenuItem();
            this.AvtoSave = new System.Windows.Forms.ToolStripMenuItem();
            this.seconds30 = new System.Windows.Forms.ToolStripMenuItem();
            this.minute1 = new System.Windows.Forms.ToolStripMenuItem();
            this.minute5 = new System.Windows.Forms.ToolStripMenuItem();
            this.minute10 = new System.Windows.Forms.ToolStripMenuItem();
            this.Color = new System.Windows.Forms.ToolStripMenuItem();
            this.Creat = new System.Windows.Forms.ToolStripComboBox();
            this.fontDialog1 = new System.Windows.Forms.FontDialog();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.T1 = new System.Windows.Forms.TabPage();
            this.richTextBoxFirst = new System.Windows.Forms.RichTextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.SelectAll = new System.Windows.Forms.ToolStripMenuItem();
            this.Cut = new System.Windows.Forms.ToolStripMenuItem();
            this.Copy = new System.Windows.Forms.ToolStripMenuItem();
            this.Paste = new System.Windows.Forms.ToolStripMenuItem();
            this.FormatContext = new System.Windows.Forms.ToolStripMenuItem();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.menuStrip1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.T1.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Fail,
            this.Edit,
            this.Format,
            this.Options});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(981, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // Fail
            // 
            this.Fail.AutoToolTip = true;
            this.Fail.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Open,
            this.SaveAs,
            this.Save,
            this.NewWindow});
            this.Fail.Name = "Fail";
            this.Fail.Size = new System.Drawing.Size(59, 24);
            this.Fail.Text = "Файл";
            // 
            // Open
            // 
            this.Open.Name = "Open";
            this.Open.Size = new System.Drawing.Size(194, 26);
            this.Open.Text = "Открыть";
            // 
            // SaveAs
            // 
            this.SaveAs.Name = "SaveAs";
            this.SaveAs.Size = new System.Drawing.Size(194, 26);
            this.SaveAs.Text = "Сохранить как";
            // 
            // Save
            // 
            this.Save.Name = "Save";
            this.Save.Size = new System.Drawing.Size(194, 26);
            this.Save.Text = "Сохранить";
            // 
            // NewWindow
            // 
            this.NewWindow.Name = "NewWindow";
            this.NewWindow.Size = new System.Drawing.Size(194, 26);
            this.NewWindow.Text = "Новая вкладка";
            // 
            // Edit
            // 
            this.Edit.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SelectAllTextEdit,
            this.CopyEdit,
            this.PasteEdit,
            this.CutEdit,
            this.FormatEdit});
            this.Edit.Name = "Edit";
            this.Edit.Size = new System.Drawing.Size(74, 24);
            this.Edit.Text = "Правка";
            // 
            // SelectAllTextEdit
            // 
            this.SelectAllTextEdit.Name = "SelectAllTextEdit";
            this.SelectAllTextEdit.Size = new System.Drawing.Size(225, 26);
            this.SelectAllTextEdit.Text = "Выбрать весь текст";
            // 
            // CopyEdit
            // 
            this.CopyEdit.Name = "CopyEdit";
            this.CopyEdit.Size = new System.Drawing.Size(225, 26);
            this.CopyEdit.Text = "Копировать";
            // 
            // PasteEdit
            // 
            this.PasteEdit.Name = "PasteEdit";
            this.PasteEdit.Size = new System.Drawing.Size(225, 26);
            this.PasteEdit.Text = "Вставить";
            // 
            // CutEdit
            // 
            this.CutEdit.Name = "CutEdit";
            this.CutEdit.Size = new System.Drawing.Size(225, 26);
            this.CutEdit.Text = "Вырезать";
            // 
            // FormatEdit
            // 
            this.FormatEdit.Name = "FormatEdit";
            this.FormatEdit.Size = new System.Drawing.Size(225, 26);
            this.FormatEdit.Text = "Формат";
            // 
            // Format
            // 
            this.Format.Name = "Format";
            this.Format.Size = new System.Drawing.Size(77, 24);
            this.Format.Text = "Формат";
            // 
            // Options
            // 
            this.Options.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AvtoSave,
            this.Color});
            this.Options.Name = "Options";
            this.Options.Size = new System.Drawing.Size(98, 24);
            this.Options.Text = "Настройки";
            // 
            // AvtoSave
            // 
            this.AvtoSave.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.seconds30,
            this.minute1,
            this.minute5,
            this.minute10});
            this.AvtoSave.Name = "AvtoSave";
            this.AvtoSave.Size = new System.Drawing.Size(208, 26);
            this.AvtoSave.Text = "Автосохранение";
            // 
            // seconds30
            // 
            this.seconds30.Checked = true;
            this.seconds30.CheckState = System.Windows.Forms.CheckState.Checked;
            this.seconds30.Name = "seconds30";
            this.seconds30.Size = new System.Drawing.Size(158, 26);
            this.seconds30.Text = "30 секунд";
            // 
            // minute1
            // 
            this.minute1.Checked = true;
            this.minute1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.minute1.Name = "minute1";
            this.minute1.Size = new System.Drawing.Size(158, 26);
            this.minute1.Text = "1 минута";
            // 
            // minute5
            // 
            this.minute5.Checked = true;
            this.minute5.CheckState = System.Windows.Forms.CheckState.Checked;
            this.minute5.Name = "minute5";
            this.minute5.Size = new System.Drawing.Size(158, 26);
            this.minute5.Text = "5 минут";
            // 
            // minute10
            // 
            this.minute10.Checked = true;
            this.minute10.CheckState = System.Windows.Forms.CheckState.Checked;
            this.minute10.Name = "minute10";
            this.minute10.Size = new System.Drawing.Size(158, 26);
            this.minute10.Text = "10 минут";
            // 
            // Color
            // 
            this.Color.Name = "Color";
            this.Color.Size = new System.Drawing.Size(208, 26);
            this.Color.Text = "Цветовая гамма";
            // 
            // Creat
            // 
            this.Creat.Name = "Creat";
            this.Creat.Size = new System.Drawing.Size(121, 28);
            this.Creat.Text = "Создать";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.T1);
            this.tabControl1.Location = new System.Drawing.Point(0, 31);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(969, 544);
            this.tabControl1.TabIndex = 2;
            // 
            // T1
            // 
            this.T1.Controls.Add(this.richTextBoxFirst);
            this.T1.Location = new System.Drawing.Point(4, 29);
            this.T1.Name = "T1";
            this.T1.Padding = new System.Windows.Forms.Padding(3);
            this.T1.Size = new System.Drawing.Size(961, 511);
            this.T1.TabIndex = 0;
            this.T1.Text = "1";
            this.T1.UseVisualStyleBackColor = true;
            // 
            // richTextBoxFirst
            // 
            this.richTextBoxFirst.Location = new System.Drawing.Point(3, 3);
            this.richTextBoxFirst.Name = "richTextBoxFirst";
            this.richTextBoxFirst.Size = new System.Drawing.Size(955, 505);
            this.richTextBoxFirst.TabIndex = 0;
            this.richTextBoxFirst.Text = "";
            // 
            // timer1
            // 
            this.timer1.Interval = 30000;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SelectAll,
            this.Cut,
            this.Copy,
            this.Paste,
            this.FormatContext});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(173, 124);
            // 
            // SelectAll
            // 
            this.SelectAll.Name = "SelectAll";
            this.SelectAll.Size = new System.Drawing.Size(172, 24);
            this.SelectAll.Text = "Выделить все";
            // 
            // Cut
            // 
            this.Cut.Name = "Cut";
            this.Cut.Size = new System.Drawing.Size(172, 24);
            this.Cut.Text = "Вырезать";
            // 
            // Copy
            // 
            this.Copy.Name = "Copy";
            this.Copy.Size = new System.Drawing.Size(172, 24);
            this.Copy.Text = "Копировать";
            // 
            // Paste
            // 
            this.Paste.Name = "Paste";
            this.Paste.Size = new System.Drawing.Size(172, 24);
            this.Paste.Text = "Вставить";
            // 
            // FormatContext
            // 
            this.FormatContext.Name = "FormatContext";
            this.FormatContext.Size = new System.Drawing.Size(172, 24);
            this.FormatContext.Text = "Формат";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(981, 587);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.T1.ResumeLayout(false);
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem Fail;
        private System.Windows.Forms.ToolStripMenuItem Open;
        private System.Windows.Forms.ToolStripMenuItem Edit;
        private System.Windows.Forms.ToolStripMenuItem Format;
        private System.Windows.Forms.ToolStripMenuItem Options;
        private System.Windows.Forms.ToolStripComboBox Creat;
        private System.Windows.Forms.ToolStripMenuItem SaveAs;
        private System.Windows.Forms.FontDialog fontDialog1;
        private System.Windows.Forms.ToolStripMenuItem NewWindow;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage T1;
        private System.Windows.Forms.RichTextBox richTextBoxFirst;
        private System.Windows.Forms.ToolStripMenuItem Save;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ToolStripMenuItem AvtoSave;
        private System.Windows.Forms.ToolStripMenuItem Color;
        private System.Windows.Forms.ToolStripMenuItem seconds30;
        private System.Windows.Forms.ToolStripMenuItem minute1;
        private System.Windows.Forms.ToolStripMenuItem minute5;
        private System.Windows.Forms.ToolStripMenuItem minute10;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem SelectAll;
        private System.Windows.Forms.ToolStripMenuItem Cut;
        private System.Windows.Forms.ToolStripMenuItem Copy;
        private System.Windows.Forms.ToolStripMenuItem Paste;
        private System.Windows.Forms.ToolStripMenuItem FormatContext;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.ToolStripMenuItem SelectAllTextEdit;
        private System.Windows.Forms.ToolStripMenuItem CopyEdit;
        private System.Windows.Forms.ToolStripMenuItem PasteEdit;
        private System.Windows.Forms.ToolStripMenuItem CutEdit;
        private System.Windows.Forms.ToolStripMenuItem FormatEdit;
    }
}

