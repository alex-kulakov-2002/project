﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        List<string> namesOfFiles= new List<string>();
        int numberOfTabPage = 1;

        List<RichTextBox> richTextBoxes=new List<RichTextBox>();
        public Form1()
        {
            
            InitializeComponent();
            KeyPreview = true;
            
            if ( MessageBox.Show("Открыть файлы, которые были открыты при предыдущем запуске, применить предыдущие настройки?", "My Application",
                   MessageBoxButtons.YesNo)==DialogResult.Yes)
            {
                Start(Properties.Settings.Default.SaveNames.Split(new char[] {' ', (char)10,  (char)13 } , StringSplitOptions.RemoveEmptyEntries));
            }
            else
            {
                richTextBoxes.Add(richTextBoxFirst);
                namesOfFiles.Add(null);
                minute1.Checked = false;
                minute5.Checked = false;
                minute10.Checked = false;
            }


            Open.Click += Open_Click;
            Format.Click += Format_Click;
            NewWindow.Click += NewWindow_Click;
            SaveAs.Click += SaveAs_Click;
            Save.Click += Save_Click;
            timer1.Tick += Timer_Tick;
            seconds30.Click += Second30_Click;
            minute1.Click += Minute1_Click;
            minute5.Click += Minute5_Click;
            minute10.Click += Minute10_Click;
            
            richTextBoxFirst.ContextMenuStrip = contextMenuStrip1;
            Copy.Click += Copy_Click;
            SelectAll.Click += SelectAll_Click;
            Paste.Click += Paste_Click;
            Cut.Click += Cut_Click;
            FormatContext.Click += Format_Click;
            KeyDown += new KeyEventHandler(Key_Down);
            FormClosing += Form1_Closing;
            colorDialog1.FullOpen = true;
            // установка начального цвета для colorDialog
            colorDialog1.Color = this.BackColor;
            Color.Click += Color_Click;


            CopyEdit.Click += Copy_Click;
            SelectAllTextEdit.Click += SelectAll_Click;
            PasteEdit.Click += Paste_Click;
            CutEdit.Click += Cut_Click;
            FormatEdit.Click += Format_Click;
        }
        

        void Start(string[] names)
        {
            timer1.Interval = Properties.Settings.Default.SaveTick;
            switch (Properties.Settings.Default.SaveTick)
            {
                case 30000:
                    minute10.Checked = false;
                    seconds30.Checked = true;
                    minute1.Checked = false;
                    minute5.Checked = false;
                    break;
                case 30000*2:
                    minute10.Checked = false;
                    seconds30.Checked = false;
                    minute1.Checked = true;
                    minute5.Checked = false;
                    break;
                case 30000*10:
                    minute10.Checked = false;
                    seconds30.Checked = false;
                    minute1.Checked = false;
                    minute5.Checked = true;
                    break;
                case 30000*20:
                    minute10.Checked = true;
                    seconds30.Checked = false;
                    minute1.Checked = false;
                    minute5.Checked = false;
                    break;


            }
            int z = 0;
            if(names.Length == 0)
            {
                richTextBoxes.Add(richTextBoxFirst);
                namesOfFiles.Add(null);
            }
            foreach (string i in names)
            {
                if (i == String.Empty) continue; 
                if (z == 0)
                {
                    if (Path.GetExtension(i) == ".rtf")
                    {
                        richTextBoxFirst.LoadFile(i);
                    }
                    else
                    {
                        richTextBoxFirst.Text = File.ReadAllText(i);
                    }
                    z++;
                    richTextBoxes.Add(richTextBoxFirst);
                    namesOfFiles.Add(i);
                }
                else
                {
                    TabPage newTabPage = new TabPage();
                    numberOfTabPage++;
                    newTabPage.Text = numberOfTabPage.ToString();
                    tabControl1.TabPages.Add(newTabPage);
                    RichTextBox richTextBoxFirs = new RichTextBox();
                    richTextBoxFirs.Location = new System.Drawing.Point(3, 3);
                    richTextBoxFirs.Name = "richTextBoxFirst";
                    richTextBoxFirs.Size = new System.Drawing.Size(955, 505);
                    richTextBoxFirs.TabIndex = 0;
                    richTextBoxFirs.Text = "";
                    newTabPage.Controls.Add(richTextBoxFirs);
                    richTextBoxFirs.ContextMenuStrip = contextMenuStrip1;
                    richTextBoxes.Add(richTextBoxFirs);
                    namesOfFiles.Add(i);
                    if (Path.GetExtension(i) == ".rtf")
                    {
                        richTextBoxFirs.LoadFile(i);
                    }
                    else
                    {
                        richTextBoxFirs.Text = File.ReadAllText(i);
                    }
                }

            }
            if (Properties.Settings.Default.SaveColor != null)
            {
                this.BackColor = Properties.Settings.Default.SaveColor;
                for (int i = 0; i < richTextBoxes.Count; i++)
                {
                    richTextBoxes[i].BackColor = Properties.Settings.Default.SaveColor;
                }
            }
        }
        private void Color_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.Cancel)
                return;
            // установка цвета формы
            this.BackColor = colorDialog1.Color;
            for (int i=0;  i< richTextBoxes.Count;  i++)
            {
                richTextBoxes[i].BackColor = colorDialog1.Color;
            }

        }

        private void Form1_Closing(object sender, CancelEventArgs e)
        {
            Properties.Settings.Default.SaveNames=String.Join(" " , namesOfFiles);
            Properties.Settings.Default.SaveTick = timer1.Interval;
            Properties.Settings.Default.SaveColor = richTextBoxFirst.BackColor;
            Properties.Settings.Default.Save();
            // Determine if text has changed in the textbox by comparing to original text.
            bool flag = false;
            for (int i=0; i < richTextBoxes.Count; i++)
            {
                if (richTextBoxes[i].Text != "")
                {
                    flag = true;
                }
            }
            if (flag)
            {
                // Display a MsgBox asking the user to save changes or abort.
                DialogResult result = MessageBox.Show("Do you want to save changes to your text?", "My Application",
                   MessageBoxButtons.YesNoCancel);
                if (result == DialogResult.Yes)
                {

                    for (int i = 0; i < namesOfFiles.Count; i++)
                    {
                        if (namesOfFiles[i] == null )
                        {
                            if (richTextBoxes[i].Text!="")
                            SaveAs_Click(sender, e,i);
                        }
                        else
                        {
                            Save_Click(sender, e, i);
                        }

                    }
                }
                else if (result == DialogResult.Cancel)
                {
                    e.Cancel = true;
                     
                }
            }
        }


        private void Key_Down(object sender, KeyEventArgs e)
        {
            if (e.Control && e.KeyCode== Keys.L)
            {
                NewWindow_Click(sender, e);
            }
            if (e.Control && e.KeyCode == Keys.K)
            {
                Save_Click(sender, e);
            }
            if (e.Control && e.KeyCode == Keys.J)
            {

                for (int i = 0; i < namesOfFiles.Count; i++)
                {
                    if (namesOfFiles[i] == null)
                    {
                        SaveAs_Click(sender, e);
                    }
                    else
                    {
                        Save_Click(sender, e, i);
                    }

                }
            }
            if (e.Control && e.KeyCode == Keys.H)
            {
                Environment.Exit(0);

            }
            if (e.Control && e.KeyCode == Keys.G)
            {
                Form1 newForm = new Form1();
                newForm.Show();
            }
        }

        private void Cut_Click(object sender, EventArgs e)
        {
            string thisTab = tabControl1.SelectedTab.ToString().Split('{', '}')[1];
            int.TryParse(thisTab, out int thisTabInt);
            RichTextBox richTextBox_this = richTextBoxes[thisTabInt - 1];
            richTextBox_this.Cut();
        }

        private void Paste_Click(object sender, EventArgs e)
        {
            //Если в буфере обмен содержится текст
            if (Clipboard.ContainsText() == true)
            {
                //Извлекаем (точнее копируем) его и сохраняем в переменную
                string someText = Clipboard.GetText();

                //Выводим показываем сообщение с текстом, скопированным из буфера обмена
                string thisTab = tabControl1.SelectedTab.ToString().Split('{', '}')[1];
                int.TryParse(thisTab, out int thisTabInt);
                RichTextBox richTextBox_this = richTextBoxes[thisTabInt - 1];
                richTextBox_this.Text = richTextBox_this.Text.Insert(richTextBox_this.SelectionStart, someText);
            }
            else
            {
                //Выводим сообщение о том, что в буфере обмена нет текста
                MessageBox.Show(this, "В буфере обмена нет текста", "Сообщение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void SelectAll_Click(object sender,EventArgs e)
        {
            string thisTab = tabControl1.SelectedTab.ToString().Split('{', '}')[1];
            int.TryParse(thisTab, out int thisTabInt);
            RichTextBox richTextBox_this = richTextBoxes[thisTabInt - 1];
            richTextBox_this.SelectAll();
        }

        private void Copy_Click(object sender, EventArgs e)
        {
            string thisTab = tabControl1.SelectedTab.ToString().Split('{', '}')[1];
            int.TryParse(thisTab, out int thisTabInt);
            RichTextBox richTextBox_this = richTextBoxes[thisTabInt - 1];
            Clipboard.SetText(richTextBox_this.SelectedText);
        }
        private void Minute10_Click(object sender, EventArgs e)
        {
            timer1.Interval = 60000*10;
            minute10.Checked = true;
            seconds30.Checked = false;
            minute1.Checked = false;
            minute5.Checked = false;
        }

        private void Minute5_Click(object sender, EventArgs e)
        {
            timer1.Interval = 60000*5;
            minute10.Checked = false;
            seconds30.Checked = false;
            minute1.Checked = false;
            minute5.Checked = true;
        }

        private void Minute1_Click(object sender, EventArgs e)
        {
            timer1.Interval = 60000;
            minute10.Checked = false;
            seconds30.Checked = false;
            minute1.Checked = true;
            minute5.Checked = false;
        }

        private void Second30_Click(object sender, EventArgs e)
        {
            timer1.Interval = 30000;
            minute10.Checked = false;
            seconds30.Checked = true;
            minute1.Checked = false;
            minute5.Checked = false;
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            for (int i=0; i < namesOfFiles.Count; i++)
            {
                if (namesOfFiles[i] != null)
                {
                    Save_Click(sender, e, i);
                }
                
            }
        }
        private void NewWindow_Click (object sender, EventArgs e)
        {
            TabPage newTabPage = new TabPage();
            numberOfTabPage++;
            newTabPage.Text = numberOfTabPage.ToString();
            tabControl1.TabPages.Add(newTabPage);
            RichTextBox richTextBoxFirs = new RichTextBox();
            richTextBoxFirs.Location = new System.Drawing.Point(3, 3);
            richTextBoxFirs.Name = "richTextBoxFirst";
            richTextBoxFirs.Size = new System.Drawing.Size(955, 505);
            richTextBoxFirs.TabIndex = 0;
            richTextBoxFirs.Text = "";
            newTabPage.Controls.Add(richTextBoxFirs);
            richTextBoxFirs.ContextMenuStrip = contextMenuStrip1;
            richTextBoxFirs.BackColor = richTextBoxFirst.BackColor;
            richTextBoxes.Add(richTextBoxFirs);
            namesOfFiles.Add(null);
        }

        private void Format_Click (object sender, EventArgs e)
        {
            string thisTab=tabControl1.SelectedTab.ToString().Split('{', '}')[1];
            int.TryParse(thisTab, out int thisTabInt);
            RichTextBox richTextBox_this = richTextBoxes[thisTabInt - 1];
            try
            {
                fontDialog1.ShowColor = true;
                fontDialog1.Font = richTextBoxFirst.Font;
                fontDialog1.Color = richTextBoxFirst.ForeColor;
                if (fontDialog1.ShowDialog() != DialogResult.Cancel)
                {
                    richTextBox_this.SelectionFont = fontDialog1.Font;
                    richTextBox_this.SelectionColor = fontDialog1.Color;
                }
                }
            catch
            {
                MessageBox.Show(
                    "Не удалось установить выбранный формат",
                    "Сообщение",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Information,
                    MessageBoxDefaultButton.Button1,
                    MessageBoxOptions.DefaultDesktopOnly);
            }
            
        }
        private void Open_Click (object sender, EventArgs e)
        {
            string thisTab = tabControl1.SelectedTab.ToString().Split('{', '}')[1];
            int.TryParse(thisTab, out int thisTabInt);
            RichTextBox richTextBox_this = richTextBoxes[thisTabInt - 1];
            timer1.Enabled = true;
            try
            {
                OpenFileDialog openFile = new OpenFileDialog();
                openFile.Filter = "txt files (*.txt)|*.txt| RTF Files|*.rtf";
                if (openFile.ShowDialog()== DialogResult.OK)
                {
                    if (Path.GetExtension(openFile.FileName) == ".rtf")
                    {
                        richTextBox_this.LoadFile(openFile.FileName);
                    }
                    else
                    {
                        richTextBox_this.Text = File.ReadAllText(openFile.FileName);
                    }
                    if (namesOfFiles.Count < thisTabInt)
                    {
                        namesOfFiles.Add(openFile.FileName);
                    }
                    else
                    {
                        namesOfFiles[thisTabInt - 1] = openFile.FileName;
                    }
                }
            }
            catch
            {
                MessageBox.Show(
                    "Не удалось открыть файл",
                    "Сообщение",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Information,
                    MessageBoxDefaultButton.Button1,
                    MessageBoxOptions.DefaultDesktopOnly);
            }

        }


        private void SaveAs_Click(object sender, EventArgs e)
        {
            string thisTab = tabControl1.SelectedTab.ToString().Split('{', '}')[1];
            int.TryParse(thisTab, out int thisTabInt);
            RichTextBox richTextBox_this = richTextBoxes[thisTabInt - 1];
            try
            {
                SaveFileDialog saveFile = new SaveFileDialog();
                saveFile.Filter = "txt files (*.txt)|*.txt| RTF Files|*.rtf";
                if (saveFile.ShowDialog() == DialogResult.OK)
                {
                    if (Path.GetExtension(saveFile.FileName) == ".rtf")
                    {
                        richTextBox_this.SaveFile(saveFile.FileName);
                    }
                    else
                    {
                        File.WriteAllText(saveFile.FileName, richTextBox_this.Text);
                    }
                }
            }
            catch
            {
                MessageBox.Show(
                    "Не удалось сохранить файл",
                    "Сообщение",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Information,
                    MessageBoxDefaultButton.Button1,
                    MessageBoxOptions.DefaultDesktopOnly);
                SaveAs_Click(sender, e);
            }

        }
        private void SaveAs_Click(object sender, EventArgs e, int i)
        {
            RichTextBox richTextBox_this = richTextBoxes[i];
            try
            {
                SaveFileDialog saveFile = new SaveFileDialog();
                saveFile.Filter = "txt files (*.txt)|*.txt| RTF Files|*.rtf";
                if (saveFile.ShowDialog() == DialogResult.OK)
                {
                    if (Path.GetExtension(saveFile.FileName) == ".rtf")
                    {
                        richTextBox_this.SaveFile(saveFile.FileName);
                    }
                    else
                    {
                        File.WriteAllText(saveFile.FileName, richTextBox_this.Text);
                    }
                }
            }
            catch
            {
                MessageBox.Show(
                    "Не удалось сохранить файл",
                    "Сообщение",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Information,
                    MessageBoxDefaultButton.Button1,
                    MessageBoxOptions.DefaultDesktopOnly);
                SaveAs_Click(sender, e);
            }

        }

        private void Save_Click(object sender, EventArgs e)
        {
            string thisTab = tabControl1.SelectedTab.ToString().Split('{', '}')[1];
            int.TryParse(thisTab, out int thisTabInt);
            RichTextBox richTextBox_this = richTextBoxes[thisTabInt - 1];
            string nameOfFile = namesOfFiles[thisTabInt - 1];
            try
            {
                if (Path.GetExtension(nameOfFile) == ".rtf")
                {
                    richTextBox_this.SaveFile(nameOfFile);
                }
                else
                {
                    File.WriteAllText(nameOfFile, richTextBox_this.Text);
                }
            }
            catch
            {
                MessageBox.Show(
                    "Не удалось сохранить файл",
                    "Сообщение",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Information,
                    MessageBoxDefaultButton.Button1,
                    MessageBoxOptions.DefaultDesktopOnly);
            }

        }

        private void Save_Click(object sender, EventArgs e, int thisTabInt)
        {
            try 
            { 
                if (thisTabInt == -1)
                {
                    string thisTab = tabControl1.SelectedTab.ToString().Split('{', '}')[1];
                    int.TryParse(thisTab, out thisTabInt);
                }
                RichTextBox richTextBox_this = richTextBoxes[thisTabInt];
                string nameOfFile = namesOfFiles[thisTabInt];
            
                if (Path.GetExtension(nameOfFile) == ".rtf")
                {
                    richTextBox_this.SaveFile(nameOfFile);
                }
                else
                {
                    File.WriteAllText(nameOfFile, richTextBox_this.Text);
                }
            }
            catch
            {
                MessageBox.Show(thisTabInt.ToString()
                    //"Не удалось сохранить файл",
                    ,
                    "Сообщение",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Information,
                    MessageBoxDefaultButton.Button1,
                    MessageBoxOptions.DefaultDesktopOnly) ;
            }

        }
    }


}
