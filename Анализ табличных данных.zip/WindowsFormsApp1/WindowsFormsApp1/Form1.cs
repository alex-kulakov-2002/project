﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{

    // В программе есть длинные методы, которые инициализируют форму, но разбивать их не имеет никакого смысла,
    // такак декомпозиция нужна для читаемости кода, а они очень понятные. Да и это попросту не логично */


    public partial class Form1 : Form
    {
        List<string> namesOfColumn;
        DataTable dataTable;
        public Form1()
        {
            InitializeComponent();
        }
        
        /// <summary>
        /// Метод, осуществляющий открытие файла.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Open_Click(object sender, EventArgs e)
        {
            
            try
            {
                openFileDialog1.Filter = "*.csv|*.csv";
                openFileDialog1.ShowDialog();
                string fileName = openFileDialog1.FileName;
                BindDataCSV(fileName);
            }
            catch
            {
                MessageBox.Show("Не удалось открыть выбранный файл");
            }
        }

        /// <summary>
        /// Метод, составляющий таблицу.
        /// </summary>
        /// <param name="filePath"></param>
        private void BindDataCSV(string filePath)
        {
            DataTable dt = new DataTable();
            string[] lines = File.ReadAllLines(filePath);
            if (lines.Length > 0)
            {
                string firstLine = lines[0];
                string m = "";
                for (int i = 0; i < firstLine.Length; i++)
                {

                    if (firstLine[i] == ',' && i != firstLine.Length - 1 && firstLine[i + 1] != ' ')
                    {
                        m += '\f';
                    }
                    else
                    {
                        m += firstLine[i];
                    }
                }
                firstLine = m;
                string[] headerLabels = firstLine.Split('\f');
                int numberOfNulls = 1;
                namesOfColumn = new List<string>();
                numberOfNulls = MakesHeaderWords(dt, headerLabels, numberOfNulls);
                for (int r = 1; r < lines.Length; r++)
                {
                    string g = "";
                    for (int i = 0; i < lines[r].Length; i++)
                    {
                        if (lines[r][i] == ',' && i != lines[r].Length - 1 && lines[r][i + 1] != ' ')
                        {
                            g += '\f';
                        }
                        else
                        {
                            g += lines[r][i];
                        }
                    }
                    lines[r] = g;
                    string[] dataWords = lines[r].Split('\f');

                    DataRow dr = dt.NewRow();
                    int columnIndex = 0;
                    numberOfNulls = 1;
                    foreach (string headerWord in headerLabels)
                    {
                        if (headerWord == string.Empty) dr[new string(' ', numberOfNulls++)] = dataWords[columnIndex++];
                        else
                            dr[headerWord] = dataWords[columnIndex++];
                    }
                    dt.Rows.Add(dr);
                }
            }
            if (dt.Rows.Count > 0)
            {
                dataGridView1.DataSource = dt;
            }
            dataTable = dt;
        }


        /// <summary>
        /// Метод, парсящий названия столбцов.
        /// </summary>
        /// <param name="dt"> Таблица.</param>
        /// <param name="headerLabels"> Список названий столбцов. </param>
        /// <param name="numberOfNulls"> Количестов столбцов без названия. </param>
        /// <returns></returns>
        private int MakesHeaderWords(DataTable dt, string[] headerLabels, int numberOfNulls)
        {
            foreach (string headerWord in headerLabels)
            {

                if (headerWord == string.Empty)
                {
                    dt.Columns.Add(new DataColumn(new string(' ', numberOfNulls++)));
                    namesOfColumn.Add(new string(' ', numberOfNulls - 1));
                }
                else
                {
                    dt.Columns.Add(new DataColumn(headerWord));
                    namesOfColumn.Add(headerWord);
                }
            }

            return numberOfNulls;
        }


        /// <summary>
        /// Метод, подготавливающий информацию для рисования графика.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void GraficButton_Click(object sender, EventArgs e)
        {
            try
            {
                string XStr = textBoxForX.Text;
                string YStr = textBoxForY.Text;
                if (dataTable == null)
                {
                    MessageBox.Show("Сначала откройте файл");
                    return;
                }
                if (!int.TryParse(XStr, out int X) || !int.TryParse(YStr,out int Y) || X<=0 || Y<=0)
                {
                    MessageBox.Show("Номера столбцов должны быть натуральными числами.");
                    return;
                }
                if (dataTable.Columns.Count<X || dataTable.Columns.Count < Y)
                {
                    MessageBox.Show("В таблице нет столбцов с такими номерами");
                    return;
                }
                X--;
                Y--;
                List<double> forX = new List<double>();
                List<double> forY = new List<double>();
                for (int i=0; i < dataTable.Rows.Count; i++)
                {
                    if (!double.TryParse(((string)dataTable.Rows[i][namesOfColumn[X]]).Trim('\"'), out double newIntX) || !double.TryParse(((string)dataTable.Rows[i][namesOfColumn[Y]]).Trim('\"'), out double newIntY))
                    {
                        MessageBox.Show("Можно строить только по столбцам состоящим из числовых значений");
                        return;
                    }
                    forX.Add(newIntX);
                    forY.Add(newIntY);
                }
                DrawGrafic(forX, forY);
            }
            catch
            {
                MessageBox.Show("Не удалось нарисовать график");
            }

        }

        /// <summary>
        /// Метод, вызывающий метод для рисования графика.
        /// </summary>
        /// <param name="forX"> Координаты Х. </param>
        /// <param name="forY"> Координаты Y. </param>
        void DrawGrafic(List<double> forX, List<double> forY)
        {
            FormForGrafics form = new FormForGrafics();
            form.Show();
            form.InitializeComponent();
            form.DrawGrafic(forX, forY);
        }

        /// <summary>
        /// Метод, подготавливающий данные для построения гистограммы.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void GictogramButton_Click(object sender, EventArgs e)
        {
            try
            {
                string XStr = textBoxForGist.Text;
                if (dataTable == null)
                {
                    MessageBox.Show("Сначала откройте файл");
                    return;
                }
                if (!int.TryParse(XStr, out int X) || X <= 0)
                {
                    MessageBox.Show("Номера столбцов должны быть натуральными числами.");
                    return;
                }
                if (dataTable.Columns.Count < X)
                {
                    MessageBox.Show("В таблице нет столбцов с такими номерами");
                    return;
                }
                X--;
                List<string> forX = new List<string>();
                for (int i = 0; i < dataTable.Rows.Count; i++)
                {
                    forX.Add(((string)dataTable.Rows[i][namesOfColumn[X]]).Trim('\"'));
                }
                FormForGistigram formGist = new FormForGistigram();
                formGist.Show();
                formGist.DrawGistogram(forX);
            }
            catch
            {
                MessageBox.Show("Не удалось построить гистограмму");
            }
        }

        /// <summary>
        /// Метод, осуществляющий анализ столбца.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AnaliticButton_Click(object sender, EventArgs e)
        {
            try
            {
                string XStr = textBoxForAnalitic.Text;
                if (dataTable == null)
                {
                    MessageBox.Show("Сначала откройте файл");
                    return;
                }
                if (!int.TryParse(XStr, out int X) || X <= 0)
                {
                    MessageBox.Show("Номера столбцов должны быть натуральными числами.");
                    return;
                }
                if (dataTable.Columns.Count < X)
                {
                    MessageBox.Show("В таблице нет столбцов с такими номерами");
                    return;
                }
                X--;
                List<double> forX = new List<double>();
                for (int i = 0; i < dataTable.Rows.Count; i++)
                {
                    if (!double.TryParse(((string)dataTable.Rows[i][namesOfColumn[X]]).Trim('\"'), out double newIntX))
                    {
                        MessageBox.Show("Можно считать только по столбцам состоящим из числовых значений");
                        return;
                    }
                    forX.Add(newIntX);
                }
                double sum = 0;
                foreach (double i in forX)
                {
                    sum += i;
                }
                labelAverege.Text = (sum / forX.Count).ToString();
                if (forX.Count % 2 == 0)
                    labelMedian.Text = ((forX[forX.Count / 2] + forX[forX.Count / 2 - 1]) / 2.0).ToString();
                else labelMedian.Text = forX[forX.Count / 2].ToString();

                double summ = 0;
                foreach (double i in forX)
                {
                    summ += i;
                }
                double sumOfDevation = 0;
                foreach (double i in forX)
                {
                    sumOfDevation += Math.Pow(summ / forX.Count - i, 2);
                }
                labelDeviation.Text = Math.Pow(sumOfDevation / (forX.Count - 1), 0.5).ToString();
                labelVariance.Text = (sumOfDevation / (forX.Count - 1)).ToString();
            }
            catch
            {
                MessageBox.Show("Не удалось проанализировать столбец");
            }

        }

        private void Referense_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Для работы со столбцом нужно указывать его номер, а не название." + Environment.NewLine+
                "Также при работе с гистограммой(числовой) указывать нужно именно количество столбцов," + Environment.NewLine +
                "которые должны быть на гистограмме, а не ширину отдельного столбца." + Environment.NewLine +
                "Также важно учитывать, что если вы хотите, чтобы программа работала с нецелыми числами," +
                " то нужно указывать их с разделителем: запятая.");
        }
    }
}
