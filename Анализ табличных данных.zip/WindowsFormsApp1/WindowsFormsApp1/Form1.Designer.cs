﻿
namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.textBoxForX = new System.Windows.Forms.TextBox();
            this.textBoxForY = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxForGist = new System.Windows.Forms.TextBox();
            this.GraficButton = new System.Windows.Forms.Button();
            this.GictogramButton = new System.Windows.Forms.Button();
            this.textBoxForAnalitic = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.AnaliticButton = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.labelMedian = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.labelDeviation = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.labelVariance = new System.Windows.Forms.Label();
            this.labelAverege = new System.Windows.Forms.Label();
            this.ReverenseButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(547, 346);
            this.dataGridView1.TabIndex = 0;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(52, 387);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(83, 28);
            this.button1.TabIndex = 1;
            this.button1.Text = "Выбрать файл";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Open_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // textBoxForX
            // 
            this.textBoxForX.Location = new System.Drawing.Point(864, 24);
            this.textBoxForX.Name = "textBoxForX";
            this.textBoxForX.Size = new System.Drawing.Size(100, 22);
            this.textBoxForX.TabIndex = 2;
            // 
            // textBoxForY
            // 
            this.textBoxForY.Location = new System.Drawing.Point(864, 66);
            this.textBoxForY.Name = "textBoxForY";
            this.textBoxForY.Size = new System.Drawing.Size(100, 22);
            this.textBoxForY.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(710, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(136, 17);
            this.label1.TabIndex = 4;
            this.label1.Text = "Столбец для оси X:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(710, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(136, 17);
            this.label2.TabIndex = 5;
            this.label2.Text = "Столбец для оси Y:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(662, 103);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(184, 17);
            this.label3.TabIndex = 6;
            this.label3.Text = "Столбец для гистограммы:";
            // 
            // textBoxForGist
            // 
            this.textBoxForGist.Location = new System.Drawing.Point(863, 105);
            this.textBoxForGist.Name = "textBoxForGist";
            this.textBoxForGist.Size = new System.Drawing.Size(100, 22);
            this.textBoxForGist.TabIndex = 7;
            // 
            // GraficButton
            // 
            this.GraficButton.Location = new System.Drawing.Point(706, 173);
            this.GraficButton.Name = "GraficButton";
            this.GraficButton.Size = new System.Drawing.Size(255, 30);
            this.GraficButton.TabIndex = 8;
            this.GraficButton.Text = "Построить график";
            this.GraficButton.UseVisualStyleBackColor = true;
            this.GraficButton.Click += new System.EventHandler(this.GraficButton_Click);
            // 
            // GictogramButton
            // 
            this.GictogramButton.Location = new System.Drawing.Point(706, 209);
            this.GictogramButton.Name = "GictogramButton";
            this.GictogramButton.Size = new System.Drawing.Size(255, 30);
            this.GictogramButton.TabIndex = 9;
            this.GictogramButton.Text = "Построить гистограмму";
            this.GictogramButton.UseVisualStyleBackColor = true;
            this.GictogramButton.Click += new System.EventHandler(this.GictogramButton_Click);
            // 
            // textBoxForAnalitic
            // 
            this.textBoxForAnalitic.Location = new System.Drawing.Point(863, 140);
            this.textBoxForAnalitic.Name = "textBoxForAnalitic";
            this.textBoxForAnalitic.Size = new System.Drawing.Size(100, 22);
            this.textBoxForAnalitic.TabIndex = 10;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(694, 140);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(155, 17);
            this.label4.TabIndex = 11;
            this.label4.Text = "Столбец для анализа:";
            // 
            // AnaliticButton
            // 
            this.AnaliticButton.Location = new System.Drawing.Point(706, 247);
            this.AnaliticButton.Name = "AnaliticButton";
            this.AnaliticButton.Size = new System.Drawing.Size(255, 30);
            this.AnaliticButton.TabIndex = 12;
            this.AnaliticButton.Text = "Анализ столбца";
            this.AnaliticButton.UseVisualStyleBackColor = true;
            this.AnaliticButton.Click += new System.EventHandler(this.AnaliticButton_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(619, 300);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(141, 17);
            this.label5.TabIndex = 16;
            this.label5.Text = "Среднгее значение:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(689, 346);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 17);
            this.label6.TabIndex = 18;
            this.label6.Text = "Медиана:";
            // 
            // labelMedian
            // 
            this.labelMedian.AutoSize = true;
            this.labelMedian.Location = new System.Drawing.Point(767, 346);
            this.labelMedian.Name = "labelMedian";
            this.labelMedian.Size = new System.Drawing.Size(0, 17);
            this.labelMedian.TabIndex = 19;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(524, 386);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(236, 17);
            this.label8.TabIndex = 20;
            this.label8.Text = "Среднеквадратичное отклонение:";
            // 
            // labelDeviation
            // 
            this.labelDeviation.AutoSize = true;
            this.labelDeviation.Location = new System.Drawing.Point(770, 386);
            this.labelDeviation.Name = "labelDeviation";
            this.labelDeviation.Size = new System.Drawing.Size(0, 17);
            this.labelDeviation.TabIndex = 21;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(675, 421);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(85, 17);
            this.label10.TabIndex = 22;
            this.label10.Text = "Дисперсия:";
            // 
            // labelVariance
            // 
            this.labelVariance.AutoSize = true;
            this.labelVariance.Location = new System.Drawing.Point(767, 421);
            this.labelVariance.Name = "labelVariance";
            this.labelVariance.Size = new System.Drawing.Size(0, 17);
            this.labelVariance.TabIndex = 23;
            // 
            // labelAverege
            // 
            this.labelAverege.AutoSize = true;
            this.labelAverege.Location = new System.Drawing.Point(770, 299);
            this.labelAverege.Name = "labelAverege";
            this.labelAverege.Size = new System.Drawing.Size(0, 17);
            this.labelAverege.TabIndex = 24;
            // 
            // ReverenseButton
            // 
            this.ReverenseButton.Location = new System.Drawing.Point(52, 433);
            this.ReverenseButton.Name = "ReverenseButton";
            this.ReverenseButton.Size = new System.Drawing.Size(83, 27);
            this.ReverenseButton.TabIndex = 25;
            this.ReverenseButton.Text = "Справка";
            this.ReverenseButton.UseVisualStyleBackColor = true;
            this.ReverenseButton.Click += new System.EventHandler(this.Referense_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1034, 499);
            this.Controls.Add(this.ReverenseButton);
            this.Controls.Add(this.labelAverege);
            this.Controls.Add(this.labelVariance);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.labelDeviation);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.labelMedian);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.AnaliticButton);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBoxForAnalitic);
            this.Controls.Add(this.GictogramButton);
            this.Controls.Add(this.GraficButton);
            this.Controls.Add(this.textBoxForGist);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxForY);
            this.Controls.Add(this.textBoxForX);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.TextBox textBoxForX;
        private System.Windows.Forms.TextBox textBoxForY;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxForGist;
        private System.Windows.Forms.Button GraficButton;
        private System.Windows.Forms.Button GictogramButton;
        private System.Windows.Forms.TextBox textBoxForAnalitic;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button AnaliticButton;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label labelMedian;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label labelDeviation;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label labelVariance;
        private System.Windows.Forms.Label labelAverege;
        private System.Windows.Forms.Button ReverenseButton;
    }
}

