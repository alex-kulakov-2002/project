﻿using System;
using System.IO;
using System.Linq;
using System.Windows.Forms.DataVisualization.Charting;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    /// <summary>
    /// Форма, отвечающая за рисование гистограммы.
    /// </summary>
    class FormForGistigram: Form
    {

        private  List<PointF> informations = new List<PointF>();
        private NumericUpDown numericUpDown1;
        private Button button1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;

        public FormForGistigram()
        {
            InitializeComponent();
        }
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.SuspendLayout();
            // 
            // chart1
            // 
            chartArea1.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea1);
            this.chart1.Dock = System.Windows.Forms.DockStyle.Fill;
            legend1.Name = "Legend1";
            this.chart1.Legends.Add(legend1);
            this.chart1.Location = new System.Drawing.Point(0, 0);
            this.chart1.Name = "chart1";
            this.chart1.Size = new System.Drawing.Size(869, 732);
            this.chart1.TabIndex = 0;
            this.chart1.Text = "chart1";
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.numericUpDown1.Location = new System.Drawing.Point(0, 710);
            this.numericUpDown1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(869, 22);
            this.numericUpDown1.TabIndex = 1;
            this.numericUpDown1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown1.Visible = false;
            // 
            // button1
            // 
            this.button1.Dock = System.Windows.Forms.DockStyle.Top;
            this.button1.Location = new System.Drawing.Point(0, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(869, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "Сохранить";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Save_Click);
            // 
            // FormForGistigram
            // 
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(869, 732);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.chart1);
            this.Name = "FormForGistigram";
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.ResumeLayout(false);
            numericUpDown1.ValueChanged += NumericUpDown1_ValueChanged;
        }


        /// <summary>
        /// Метод, осуществляющий перерисовку графика, при изменении количества столбцов.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void NumericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            if (informations.Count == 0) return;
            List<PointF> newInformations = new List<PointF>();
            int count =(int) numericUpDown1.Value;
            chart1.Series.Clear();
            int[] number = new int[count];
            int len = informations.Count;
            int l = 0;
            while (len % count != 0)
            {
                int k = len / count + 1;
                number[l] = k;
                l++;
                len -= k;
                count -= 1;
            }
            int k1 = len / count;
            for (int i = number.Length-count; i < number.Length; i++)
            {
                number[i] = k1;
            }
            string result = "";
            for (int i=0; i < number.Length; i++)
            {
                result += number[i].ToString() + ' ';
            }
            
            int z = 0;
            for (int i=0; i<number.Length;i++)
            {
                double sum = 0;
                for (int j =z ; j<z+number[i]; j++)
                {
                    sum += informations[j].Y;
                }
                Series seriesOper;
                if (z == z + number[i] - 1)
                {
                    seriesOper = new Series(informations[z].X.ToString());
                }
                else
                {
                    seriesOper = new Series(informations[z].X.ToString() + " : " + informations[z + number[i] - 1].X.ToString());
                }
                var dp1 = seriesOper.Points.Add(sum);
                chart1.Series.Add(seriesOper);
                z += number[i];
            }

        }


        /// <summary>
        /// Метод, рисующий гистограмму.
        /// </summary>
        /// <param name="data"> Список, по которому надо построить гистограмму. </param>
        public void DrawGistogram(List<string> data)
        {
            Dictionary<string,int> dict= new Dictionary<string, int>();
            bool flag = true;
            foreach (string i in data)
            {
                if (!double.TryParse(i, out double z)) flag = false;
            }
            if (!flag)
            {
                foreach (string i in data)
                {
                    if (dict.ContainsKey(i)) dict[i]++;
                    else dict[i] = 1;
                }
                foreach (KeyValuePair<string, int> i in dict)
                {
                    Series seriesOper = new Series(i.Key);
                    //seriesOper.AxisLabel = i.Key;
                    var dp1 = seriesOper.Points.Add(i.Value); // значение по Y
                    chart1.Series.Add(seriesOper);
                }
            }
            else
            {
                numericUpDown1.Visible = true;
                
                foreach (string i in data)
                {
                    if (dict.ContainsKey(i)) dict[i]++;
                    else dict[i] = 1;
                }
                List<PointF> informations = new List<PointF>();
                foreach (KeyValuePair<string, int> i in dict)
                {
                    informations.Add(new PointF(float.Parse(i.Key), i.Value));
                }
                numericUpDown1.Maximum = informations.Count;
                numericUpDown1.Value = informations.Count;

                informations =informations.OrderBy(x => x.X).ToList();
                this.informations = informations;
                foreach (PointF i in informations)
                {
                    Series seriesOper = new Series(i.X.ToString());
                    var dp1 = seriesOper.Points.Add(i.Y);
                    chart1.Series.Add(seriesOper);
                }
            }

        }


        /// <summary>
        /// Метод, осуществляющий сохранение гистограммы.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Save_Click(object sender, EventArgs e)
        {
            try
            {
                using (SaveFileDialog saveFileDialog = new SaveFileDialog())
                {
                    
                    saveFileDialog.Filter = "*.bmp|*.bmp;|*.png|*.png;|*.jpg|*.jpg";
                    saveFileDialog.Title = "Сохранить изображение как";
                    saveFileDialog.AddExtension = true;
                    saveFileDialog.FileName = "Image";

                    if (saveFileDialog.ShowDialog() == DialogResult.OK)
                    {
                        switch (saveFileDialog.FilterIndex)
                        {
                            case 1: chart1.SaveImage(saveFileDialog.FileName, System.Windows.Forms.DataVisualization.Charting.ChartImageFormat.Bmp); break;
                            case 2: chart1.SaveImage(saveFileDialog.FileName, System.Windows.Forms.DataVisualization.Charting.ChartImageFormat.Png); break;
                            case 3: chart1.SaveImage(saveFileDialog.FileName, System.Windows.Forms.DataVisualization.Charting.ChartImageFormat.Jpeg); break;
                        }

                        MessageBox.Show("Изображение графика сохранено");
                    }
                }
            }
            catch
            {
                MessageBox.Show("Не удалось сохранить график");
            }
        }
    }
}
