﻿using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    /// <summary>
    /// Форма для рисования графиков.
    /// </summary>
    public class FormForGrafics: Form
    {
        private Button button1;
        public System.Windows.Forms.DataVisualization.Charting.Chart chart1;

        public void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.SuspendLayout();
            // 
            // chart1
            // 
            chartArea2.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea2);
            this.chart1.Dock = System.Windows.Forms.DockStyle.Fill;
            legend2.Name = "Legend1";
            this.chart1.Legends.Add(legend2);
            this.chart1.Location = new System.Drawing.Point(0, 0);
            this.chart1.Name = "chart1";
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series2.Legend = "Legend1";
            series2.Name = "Series1";
            this.chart1.Series.Add(series2);
            this.chart1.Size = new System.Drawing.Size(1022, 761);
            this.chart1.TabIndex = 0;
            this.chart1.Text = "chart1";
            // 
            // button1
            // 
            this.button1.Dock = System.Windows.Forms.DockStyle.Top;
            this.button1.Location = new System.Drawing.Point(0, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(1022, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "Сохранить";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Save_Click);
            // 
            // Form2
            // 
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1022, 761);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.chart1);
            this.Name = "Form2";
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.ResumeLayout(false);

        }
        /// <summary>
        /// Метод рисования графика.
        /// </summary>
        /// <param name="forX"> Значение координат X. </param>
        /// <param name="forY"> Значения координат Y. </param>
        public void DrawGrafic(List<double> forX, List<double> forY)
        {
            PointF[] gr = new PointF[forX.Count];
            for (int i=0; i < forX.Count; i++)
            {
                gr[i].X =(float) forX[i];
                gr[i].Y = (float)forY[i];
            }
            double[] h = new double[5];
            gr=gr.OrderBy(x => x.X).ToArray();
            for (int i = 0; i < gr.Length; i++)
            {
                chart1.Series["Series1"].Points.AddXY(gr[i].X,gr[i].Y);
            }
        }

        /// <summary>
        /// Метод, осуществляющий сохранение графика.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Save_Click(object sender, EventArgs e)
        {
            try
            {
                using (SaveFileDialog saveFileDialog = new SaveFileDialog())
                {
                    saveFileDialog.Filter = "*.bmp|*.bmp;|*.png|*.png;|*.jpg|*.jpg";
                    saveFileDialog.Title = "Сохранить изображение как";
                    
                    saveFileDialog.AddExtension = true;
                    saveFileDialog.FileName = "Image";

                    if (saveFileDialog.ShowDialog() == DialogResult.OK)
                    {
                        switch (saveFileDialog.FilterIndex)
                        {
                            case 1:
                                chart1.SaveImage(saveFileDialog.FileName, System.Windows.Forms.DataVisualization.Charting.ChartImageFormat.Bmp); 
                                break;
                            case 2:
                                chart1.SaveImage(saveFileDialog.FileName, System.Windows.Forms.DataVisualization.Charting.ChartImageFormat.Png);
                                break;
                            case 3:
                                chart1.SaveImage(saveFileDialog.FileName, System.Windows.Forms.DataVisualization.Charting.ChartImageFormat.Jpeg);
                                break;
                        }

                        MessageBox.Show("Изображение графика сохранено");
                    }
                }
            }
            catch 
            {
                MessageBox.Show("Не удалось сохранить график");
            }
        }
    }
}

