﻿using System.Drawing;

namespace WindowsFormsApp1
{
    /// <summary>
    /// Класс наследник от класса Fractal, реализует ковер Серпинского.
    /// </summary>
    public class SierpinskiCarpet:Fractal
    {

        /// <summary>
        /// 
        /// </summary>
        /// <param name="leftUpAngle"> Левый верхний угол квадрата.</param>
        /// <param name="rightDownAngle"> Правый нижний угол квадрата.</param>
        /// <param name="none"> Бессмысленный параметр, добавлен из-за наследования от класса Fractal.</param>
        /// <param name="depthOfRecursion"> Глубина рекурсии.</param>
        public override void DrowFractal(PointF leftUpAngle, PointF rightDownAngle, PointF none, int depthOfRecursion)
        {
            if (depthOfRecursion == 0)
            {
                return;
            }
            else 
            {
                RectangleF k = new RectangleF(leftUpAngle.X+(rightDownAngle.X-leftUpAngle.X)/3, leftUpAngle.Y + (rightDownAngle.Y - leftUpAngle.Y) / 3, (rightDownAngle.X - leftUpAngle.X) / 3, (rightDownAngle.Y - leftUpAngle.Y) / 3);
                Form1.gr.FillRectangle(Form1.brush1, k);
                PointF z1 = new PointF(0, 0);
                PointF p1 = new PointF(leftUpAngle.X + (rightDownAngle.X - leftUpAngle.X) / 3, leftUpAngle.Y + (rightDownAngle.X - leftUpAngle.X) / 3);
                DrowFractal(leftUpAngle, p1, z1, depthOfRecursion - 1);

                PointF p2 = new PointF(leftUpAngle.X, leftUpAngle.Y + (rightDownAngle.X - leftUpAngle.X) / 3);
                PointF p3 = new PointF(leftUpAngle.X + (rightDownAngle.X - leftUpAngle.X) / 3, leftUpAngle.Y + 2*(rightDownAngle.X - leftUpAngle.X) / 3);
                DrowFractal(p2, p3, z1, depthOfRecursion - 1);

                PointF p4 = new PointF(leftUpAngle.X , leftUpAngle.Y + 2*(rightDownAngle.X - leftUpAngle.X) / 3);
                PointF p5 = new PointF(leftUpAngle.X + (rightDownAngle.X - leftUpAngle.X) / 3, rightDownAngle.Y);
                DrowFractal(p4, p5, z1, depthOfRecursion - 1);

                PointF p6 = new PointF(leftUpAngle.X + (rightDownAngle.X - leftUpAngle.X) / 3, leftUpAngle.Y + 2*(rightDownAngle.X - leftUpAngle.X) / 3);
                PointF p7 = new PointF(leftUpAngle.X + 2*(rightDownAngle.X - leftUpAngle.X) / 3, rightDownAngle.Y);
                DrowFractal(p6, p7, z1, depthOfRecursion - 1);

                PointF p8 = new PointF(leftUpAngle.X + 2*(rightDownAngle.X - leftUpAngle.X) / 3, leftUpAngle.Y + 2*(rightDownAngle.X - leftUpAngle.X) / 3);
                DrowFractal(p8, rightDownAngle, z1, depthOfRecursion - 1);
                
                PointF p9 = new PointF(leftUpAngle.X + 2*(rightDownAngle.X - leftUpAngle.X) / 3, leftUpAngle.Y + (rightDownAngle.X - leftUpAngle.X) / 3);
                PointF p10 = new PointF(rightDownAngle.X, leftUpAngle.Y + 2*(rightDownAngle.X - leftUpAngle.X) / 3);
                DrowFractal(p9, p10, z1, depthOfRecursion - 1);

                PointF p11 = new PointF(leftUpAngle.X + 2*(rightDownAngle.X - leftUpAngle.X) / 3, leftUpAngle.Y);
                PointF p12 = new PointF(rightDownAngle.X, leftUpAngle.Y + (rightDownAngle.X - leftUpAngle.X) / 3);
                DrowFractal(p11, p12, z1, depthOfRecursion - 1);

                PointF p13 = new PointF(leftUpAngle.X + (rightDownAngle.X - leftUpAngle.X) / 3, leftUpAngle.Y);
                PointF p14 = new PointF(leftUpAngle.X + 2*(rightDownAngle.X - leftUpAngle.X) / 3, leftUpAngle.Y + (rightDownAngle.X - leftUpAngle.X) / 3);
                DrowFractal(p13, p14, z1, depthOfRecursion - 1);
            }
        }
    }
}
