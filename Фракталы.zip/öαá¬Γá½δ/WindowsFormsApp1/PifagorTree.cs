﻿using System;
using System.Drawing;

namespace WindowsFormsApp1
{
    /// <summary>
    /// Класс наследник от класса Fractal, реализует дерево Пифагора.
    /// </summary>
    public class PifagorTree: Fractal
    {

        /// <summary>
        /// 
        /// </summary>
        /// <param name="startPoint"> Начальная точка отрезка</param>
        /// <param name="lastPoint"> Конечная точка отрезка</param>
        /// <param name="none"> Бессмысленный параметр, добавлен из-за наследования от класса Fractal.</param>
        /// <param name="depthOfRecursion"> Глубина рекурсии.</param>
        public override void DrowFractal(PointF startPoint, PointF lastPoint, PointF none, int depthOfRecursion)
        {
            if (depthOfRecursion == 0)
            {
                return;
            }
            else 
            {
                double lng = Form1.length / Math.Pow(Form1.indent / 10.0, Form1.RecursionBar - depthOfRecursion);
                Form1.gr.DrawLine(Form1.pen1, startPoint, lastPoint);
                double corner;
                if (startPoint.Y-lastPoint.Y == 0)
                {
                    corner = startPoint.X > lastPoint.X ? Math.PI : 0;
                }
                else
                {
                    corner = Math.Atan((double)(lastPoint.X - startPoint.X) / (startPoint.Y - lastPoint.Y));
                    if (lastPoint.Y > startPoint.Y)
                    {
                        corner *= -1;
                    }
                    corner = Math.PI / 2 - corner;
                }
                if (lastPoint.Y > startPoint.Y)
                {
                    corner *= -1;
                }

                double corner1 = Form1.slant1 / 180.0 * Math.PI;
                double corner2 = Form1.slant2 / 180.0 * Math.PI;


                PointF x1 = new PointF((float)(lastPoint.X+lng*Math.Cos(corner2+corner-Math.PI/2)),
                    (float)(lastPoint.Y - lng * Math.Sin(corner2 + corner - Math.PI / 2))) ;
                PointF y1 = new PointF((float)(lastPoint.X + lng * Math.Cos(corner1 + corner - Math.PI / 2)),
                    (float)(lastPoint.Y - lng * Math.Sin(corner1 + corner - Math.PI / 2)));
                
                DrowFractal(lastPoint, x1, new PointF(), depthOfRecursion - 1);
                DrowFractal(lastPoint, y1, new PointF(), depthOfRecursion - 1);
            }

        }
    }
}
