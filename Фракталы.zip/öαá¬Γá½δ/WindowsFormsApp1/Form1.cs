﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    /// <summary>
    /// Класс в котором описано взаимодействие программы с формой.
    /// </summary>
    public partial class Form1 : Form
    {
        // Отвечает за тип фрактала.
         public  static int TypeOfFractal=0;
        // Отвечает за глубину рекурсии.
        public static int RecursionBar=1;
        // Отвечает за отступ в множестве кантора и за отношение длин отрезков в Пифагоровом дереве.
        public static int indent = 20;
        public static SolidBrush brush2 = new SolidBrush(Color.Blue);
        public static SolidBrush brush1 = new SolidBrush(Color.White);

        // Углы наклонов отрезков в дереве Пифагора.
        public static int slant1 = 45;
        public static int slant2 = 100;

        public static Pen pen1 = new Pen(Color.Black, 2);
        public static Pen pen3 = new Pen(Color.Black, 10);
        public static Pen pen2 = new Pen(Color.White, 2);
        public static Pen pen4 = new Pen(Color.White, 10);
        public static Graphics gr;
        // Длинна первого отрезка в дереве Пифагора.
        public static double length = 100;
        public Form1()
        {
            InitializeComponent();
        }


       
        
        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            
            if (e.ClickedItem.ToString() == "Дерево Пифагора")
            {
                PifagorTreeChosen();
            }
            else if (e.ClickedItem.ToString() == "Кривая Коха")
            {
                KochChosen();
            }
            else if (e.ClickedItem.ToString() == "Ковер Серпинского")
            {
                SierpinskiCapetChosen();
            }
            else if (e.ClickedItem.ToString() == "Треугольник Серпинского")
            {
                SierpinskiTriangleChosen();
            }
            else if (e.ClickedItem.ToString() == " Множество Кантора")
            {
                CantorSetChosen();
            }
        }

        /// <summary>
        ///  Следующие 5 методов настраивают начальные условия после выбора фрактала
        /// (например элементы, которые будут отображаться).
       /// </summary>
        private void CantorSetChosen()
        {
            indent = 20;
            recursionBar.Value = 1;
            RecursionBarLabel.Text = "" + recursionBar.Value;
            TypeOfFractal = 5;
            NameOfFractal.Text = " Множество Кантора";
            IndentBar.Visible = true;
            indentLabel.Visible = true;
            indentLabel2.Visible = true;
            recursionBar.Maximum = 13;
            IndentBar.Minimum = 20;
            IndentBar.Maximum = 32;
            IndentBar.Value = 20;
            indentLabel.Text = "" + (IndentBar.Value - 10);
            indentLabel2.Text = "Расстояние между отрезками:";
            slantBar1.Visible = false;
            slantBar2.Visible = false;
            slantlabel11.Visible = false;
            slantlabel12.Visible = false;
            slantlabel21.Visible = false;
            slantlabel22.Visible = false;
            RecursionBar = 1;
        }

        private void SierpinskiTriangleChosen()
        {
            recursionBar.Value = 1;
            RecursionBarLabel.Text = "" + recursionBar.Value;
            TypeOfFractal = 4;
            NameOfFractal.Text = "Треугольник Серпинского";
            IndentBar.Visible = false;
            indentLabel.Visible = false;
            indentLabel2.Visible = false;
            recursionBar.Maximum = 13;
            slantBar1.Visible = false;
            slantBar2.Visible = false;
            slantlabel11.Visible = false;
            slantlabel12.Visible = false;
            slantlabel21.Visible = false;
            slantlabel22.Visible = false;
            RecursionBar = 1;
        }

        private void SierpinskiCapetChosen()
        {
            recursionBar.Value = 1;
            RecursionBarLabel.Text = "" + recursionBar.Value;
            TypeOfFractal = 3;
            NameOfFractal.Text = "Ковер Серпинского";
            recursionBar.Maximum = 10;
            IndentBar.Visible = false;
            indentLabel.Visible = false;
            indentLabel2.Visible = false;
            slantBar1.Visible = false;
            slantBar2.Visible = false;
            slantlabel11.Visible = false;
            slantlabel12.Visible = false;
            slantlabel21.Visible = false;
            slantlabel22.Visible = false;
            RecursionBar = 1;
        }

        private void KochChosen()
        {
            recursionBar.Value = 1;
            RecursionBarLabel.Text = "" + recursionBar.Value;
            TypeOfFractal = 2;
            NameOfFractal.Text = "Кривая Коха";
            IndentBar.Visible = false;
            indentLabel.Visible = false;
            indentLabel2.Visible = false;
            recursionBar.Maximum = 13;
            slantBar1.Visible = false;
            slantBar2.Visible = false;
            slantlabel11.Visible = false;
            slantlabel12.Visible = false;
            slantlabel21.Visible = false;
            slantlabel22.Visible = false;
            RecursionBar = 1;
        }

        private void PifagorTreeChosen()
        {
            indent = 18;
            length = 100;
            recursionBar.Value = 1;
            RecursionBarLabel.Text = "" + recursionBar.Value;
            TypeOfFractal = 1;
            NameOfFractal.Text = "Дерево Пифагора";
            IndentBar.Visible = true;
            indentLabel.Visible = true;
            indentLabel2.Visible = true;
            indentLabel2.Text = "Отношение длин отрезков:";
            IndentBar.Minimum = 18;
            IndentBar.Maximum = 30;
            IndentBar.Value = 18;
            recursionBar.Maximum = 13;
            indentLabel.Text = "" + (IndentBar.Value / 10.0);
            slantBar1.Visible = true;
            slantBar2.Visible = true;
            slantlabel11.Visible = true;
            slantlabel12.Visible = true;
            slantlabel21.Visible = true;
            slantlabel22.Visible = true;
            RecursionBar = 1;
        }



        /// <summary>
        /// Метод, вызываемый после нажатия кнопки рисовать.
        /// </summary>
        private void Drow_Click(object sender, EventArgs e)
        {
            gr = pictureBox1.CreateGraphics();
            gr?.Clear(Color.White);
            float width = pictureBox1.Width;
            float height = pictureBox1.Height;
            if (TypeOfFractal == 0)
            {
                System.Text.StringBuilder messageBoxCS = new System.Text.StringBuilder();
                messageBoxCS.AppendFormat("Вы не выбрали никакой фрактал");
                messageBoxCS.AppendLine();
                MessageBox.Show(messageBoxCS.ToString(), "Ошибка");
            }
            else if (TypeOfFractal == 4)
            {
                SierpinskiTriangle Frac = new SierpinskiTriangle();
                PointF firstPoint = new PointF(width / 2, height / 5);
                PointF secondPoint = new PointF((float)(width / 2 - 3 * width / (5 * Math.Sqrt(3))), 4 * height / 5);
                PointF thirdPoint = new PointF((float)(width / 2 + 3 * width / (5 * Math.Sqrt(3))), 4 * height / 5);
                Frac.DrowFractal(firstPoint,secondPoint,thirdPoint, RecursionBar);
            }
            else if (TypeOfFractal == 2)
            {
                KochCurve Frac = new KochCurve();
                PointF firstPoint = new PointF(0, height / 2);
                PointF secondPoint = new PointF(width,height/2);
                Frac.DrowFractal(firstPoint, secondPoint, new PointF(0, 0), RecursionBar);
            }
            else if (TypeOfFractal == 5)
            {
                CantorSet Frac = new CantorSet();
                PointF firstPoint = new PointF(0,10);
                PointF secondPoint = new PointF(width, 10);
                Frac.DrowFractal(firstPoint, secondPoint, new PointF(0, 0), RecursionBar);
            }
            else if (TypeOfFractal == 3)
            {
                SierpinskiCarpet Frac = new SierpinskiCarpet();
                PointF firstPoint = new PointF(0,0);
                PointF secondPoint = new PointF(width, height);
                RectangleF k = new RectangleF(0, 0, height, width);
                gr.FillRectangle(brush2, k);
                Frac.DrowFractal(firstPoint, secondPoint, new PointF(0, 0), RecursionBar);
            }
            else if (TypeOfFractal == 1)
            {
                length = 100;
                PifagorTree Frac = new PifagorTree();
                PointF firstPoint = new PointF(width/2,height);
                PointF secondPoint = new PointF(width/2, (float)(height-length));
                Frac.DrowFractal(firstPoint, secondPoint, new Point(0, 0), RecursionBar);
            }
        }


        /// <summary>
        /// Метод, отвечающий за глубину рекурсии.
        /// </summary>
        private void recursionBar_Scroll(object sender, EventArgs e)
        {
            RecursionBar = recursionBar.Value;
            RecursionBarLabel.Text = "" + recursionBar.Value;
        }


        /// <summary>
        /// Метод, отвечающий за выбор отступа в множестве Кантора и за выбор отношения отрезков в дереве Пифгора.
        /// </summary>
        private void IndentBar_Scroll(object sender, EventArgs e)
        {
            
            if (TypeOfFractal == 5)
            {
                indent = IndentBar.Value;
                indentLabel.Text = "" + (IndentBar.Value - 10);
            }
            else if (TypeOfFractal == 1)
            {
                indent = IndentBar.Value;
                indentLabel.Text = "" + (IndentBar.Value/10.0);
            }
        }


        /// <summary>
        /// Метод, отвечающий за регулировку угла наклона первого отрезка в дереве Пифгора.
        /// </summary>
        private void slantBar1_Scroll(object sender, EventArgs e)
        {
            slant1 = slantBar1.Value;
            slantlabel11.Text = "" + slantBar1.Value;
        }


        /// <summary>
        /// Метод, отвечающий за регулировку угла наклона второго отрезка в дереве Пифгора.
        /// </summary>
        private void slantBar2_Scroll(object sender, EventArgs e)
        {
            slant2 = slantBar2.Value;
            slantlabel21.Text = "" + slantBar2.Value;
        }
    }
}
