﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.PifagorTree = new System.Windows.Forms.ToolStripMenuItem();
            this.KochCurve = new System.Windows.Forms.ToolStripMenuItem();
            this.SierpinskiCarpet = new System.Windows.Forms.ToolStripMenuItem();
            this.SierpinskiTriangle = new System.Windows.Forms.ToolStripMenuItem();
            this.CantorSet = new System.Windows.Forms.ToolStripMenuItem();
            this.recursionBar = new System.Windows.Forms.TrackBar();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Drow_button = new System.Windows.Forms.Button();
            this.NameOfFractal = new System.Windows.Forms.Label();
            this.RecursionBarLabel = new System.Windows.Forms.Label();
            this.IndentBar = new System.Windows.Forms.TrackBar();
            this.indentLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.indentLabel2 = new System.Windows.Forms.Label();
            this.slantBar1 = new System.Windows.Forms.TrackBar();
            this.slantBar2 = new System.Windows.Forms.TrackBar();
            this.slantlabel11 = new System.Windows.Forms.Label();
            this.slantlabel21 = new System.Windows.Forms.Label();
            this.slantlabel12 = new System.Windows.Forms.Label();
            this.slantlabel22 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.recursionBar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.IndentBar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slantBar1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slantBar2)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.PifagorTree,
            this.KochCurve,
            this.SierpinskiCarpet,
            this.SierpinskiTriangle,
            this.CantorSet});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(826, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "Выбор";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // PifagorTree
            // 
            this.PifagorTree.Name = "PifagorTree";
            this.PifagorTree.Size = new System.Drawing.Size(149, 24);
            this.PifagorTree.Text = "Дерево Пифагора";
            // 
            // KochCurve
            // 
            this.KochCurve.Name = "KochCurve";
            this.KochCurve.Size = new System.Drawing.Size(111, 24);
            this.KochCurve.Text = "Кривая Коха";
            // 
            // SierpinskiCarpet
            // 
            this.SierpinskiCarpet.Name = "SierpinskiCarpet";
            this.SierpinskiCarpet.Size = new System.Drawing.Size(161, 24);
            this.SierpinskiCarpet.Text = "Ковер Серпинского";
            // 
            // SierpinskiTriangle
            // 
            this.SierpinskiTriangle.Name = "SierpinskiTriangle";
            this.SierpinskiTriangle.Size = new System.Drawing.Size(206, 24);
            this.SierpinskiTriangle.Text = "Треугольник Серпинского";
            // 
            // CantorSet
            // 
            this.CantorSet.Name = "CantorSet";
            this.CantorSet.Size = new System.Drawing.Size(169, 24);
            this.CantorSet.Text = " Множество Кантора";
            // 
            // recursionBar
            // 
            this.recursionBar.Location = new System.Drawing.Point(684, 45);
            this.recursionBar.Maximum = 13;
            this.recursionBar.Minimum = 1;
            this.recursionBar.Name = "recursionBar";
            this.recursionBar.Size = new System.Drawing.Size(130, 56);
            this.recursionBar.TabIndex = 1;
            this.recursionBar.Value = 1;
            this.recursionBar.Scroll += new System.EventHandler(this.recursionBar_Scroll);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(0, 45);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(400, 400);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // Drow_button
            // 
            this.Drow_button.Location = new System.Drawing.Point(720, 107);
            this.Drow_button.Name = "Drow_button";
            this.Drow_button.Size = new System.Drawing.Size(94, 29);
            this.Drow_button.TabIndex = 3;
            this.Drow_button.Text = "Рисовать";
            this.Drow_button.UseVisualStyleBackColor = true;
            this.Drow_button.Click += new System.EventHandler(this.Drow_Click);
            // 
            // NameOfFractal
            // 
            this.NameOfFractal.AutoSize = true;
            this.NameOfFractal.Location = new System.Drawing.Point(583, 387);
            this.NameOfFractal.Name = "NameOfFractal";
            this.NameOfFractal.Size = new System.Drawing.Size(145, 20);
            this.NameOfFractal.TabIndex = 4;
            this.NameOfFractal.Text = "Фрактал не выбран";
            // 
            // RecursionBarLabel
            // 
            this.RecursionBarLabel.AutoSize = true;
            this.RecursionBarLabel.Location = new System.Drawing.Point(633, 51);
            this.RecursionBarLabel.Name = "RecursionBarLabel";
            this.RecursionBarLabel.Size = new System.Drawing.Size(17, 20);
            this.RecursionBarLabel.TabIndex = 5;
            this.RecursionBarLabel.Text = "1";
            // 
            // IndentBar
            // 
            this.IndentBar.Location = new System.Drawing.Point(684, 167);
            this.IndentBar.Maximum = 32;
            this.IndentBar.Minimum = 20;
            this.IndentBar.Name = "IndentBar";
            this.IndentBar.Size = new System.Drawing.Size(130, 56);
            this.IndentBar.TabIndex = 7;
            this.IndentBar.Value = 20;
            this.IndentBar.Visible = false;
            this.IndentBar.Scroll += new System.EventHandler(this.IndentBar_Scroll);
            // 
            // indentLabel
            // 
            this.indentLabel.AutoSize = true;
            this.indentLabel.Location = new System.Drawing.Point(633, 179);
            this.indentLabel.Name = "indentLabel";
            this.indentLabel.Size = new System.Drawing.Size(25, 20);
            this.indentLabel.TabIndex = 8;
            this.indentLabel.Text = "10";
            this.indentLabel.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(489, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(138, 20);
            this.label1.TabIndex = 9;
            this.label1.Text = "Глубина рекурсии:";
            // 
            // indentLabel2
            // 
            this.indentLabel2.AutoSize = true;
            this.indentLabel2.Location = new System.Drawing.Point(409, 179);
            this.indentLabel2.Name = "indentLabel2";
            this.indentLabel2.Size = new System.Drawing.Size(218, 20);
            this.indentLabel2.TabIndex = 10;
            this.indentLabel2.Text = "Расстояние между отрезками:";
            this.indentLabel2.Visible = false;
            // 
            // slantBar1
            // 
            this.slantBar1.Location = new System.Drawing.Point(684, 229);
            this.slantBar1.Maximum = 80;
            this.slantBar1.Minimum = 45;
            this.slantBar1.Name = "slantBar1";
            this.slantBar1.Size = new System.Drawing.Size(130, 56);
            this.slantBar1.TabIndex = 11;
            this.slantBar1.Value = 45;
            this.slantBar1.Visible = false;
            this.slantBar1.Scroll += new System.EventHandler(this.slantBar1_Scroll);
            // 
            // slantBar2
            // 
            this.slantBar2.Location = new System.Drawing.Point(684, 279);
            this.slantBar2.Maximum = 135;
            this.slantBar2.Minimum = 100;
            this.slantBar2.Name = "slantBar2";
            this.slantBar2.Size = new System.Drawing.Size(130, 56);
            this.slantBar2.TabIndex = 12;
            this.slantBar2.Value = 100;
            this.slantBar2.Visible = false;
            this.slantBar2.Scroll += new System.EventHandler(this.slantBar2_Scroll);
            // 
            // slantlabel11
            // 
            this.slantlabel11.AutoSize = true;
            this.slantlabel11.Location = new System.Drawing.Point(633, 229);
            this.slantlabel11.Name = "slantlabel11";
            this.slantlabel11.Size = new System.Drawing.Size(25, 20);
            this.slantlabel11.TabIndex = 13;
            this.slantlabel11.Text = "45";
            this.slantlabel11.Visible = false;
            // 
            // slantlabel21
            // 
            this.slantlabel21.AutoSize = true;
            this.slantlabel21.Location = new System.Drawing.Point(633, 279);
            this.slantlabel21.Name = "slantlabel21";
            this.slantlabel21.Size = new System.Drawing.Size(33, 20);
            this.slantlabel21.TabIndex = 14;
            this.slantlabel21.Text = "100";
            this.slantlabel21.Visible = false;
            // 
            // slantlabel12
            // 
            this.slantlabel12.AutoSize = true;
            this.slantlabel12.Location = new System.Drawing.Point(459, 229);
            this.slantlabel12.Name = "slantlabel12";
            this.slantlabel12.Size = new System.Drawing.Size(168, 20);
            this.slantlabel12.TabIndex = 15;
            this.slantlabel12.Text = "Наклон первой линии:";
            this.slantlabel12.Visible = false;
            // 
            // slantlabel22
            // 
            this.slantlabel22.AutoSize = true;
            this.slantlabel22.Location = new System.Drawing.Point(461, 279);
            this.slantlabel22.Name = "slantlabel22";
            this.slantlabel22.Size = new System.Drawing.Size(166, 20);
            this.slantlabel22.TabIndex = 16;
            this.slantlabel22.Text = "Наклон второй линии:";
            this.slantlabel22.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(826, 450);
            this.Controls.Add(this.slantlabel22);
            this.Controls.Add(this.slantlabel12);
            this.Controls.Add(this.slantlabel21);
            this.Controls.Add(this.slantlabel11);
            this.Controls.Add(this.slantBar2);
            this.Controls.Add(this.slantBar1);
            this.Controls.Add(this.indentLabel2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.indentLabel);
            this.Controls.Add(this.IndentBar);
            this.Controls.Add(this.RecursionBarLabel);
            this.Controls.Add(this.NameOfFractal);
            this.Controls.Add(this.Drow_button);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.recursionBar);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = " ";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.recursionBar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.IndentBar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slantBar1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slantBar2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem PifagorTree;
        private System.Windows.Forms.ToolStripMenuItem KochCurve;
        private System.Windows.Forms.ToolStripMenuItem SierpinskiCarpet;
        private System.Windows.Forms.ToolStripMenuItem SierpinskiTriangle;
        private System.Windows.Forms.ToolStripMenuItem CantorSet;
        private System.Windows.Forms.TrackBar recursionBar;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button Drow_button;
        private System.Windows.Forms.Label NameOfFractal;
        private System.Windows.Forms.Label RecursionBarLabel;
        private System.Windows.Forms.TrackBar IndentBar;
        private System.Windows.Forms.Label indentLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label indentLabel2;
        private System.Windows.Forms.TrackBar slantBar1;
        private System.Windows.Forms.TrackBar slantBar2;
        private System.Windows.Forms.Label slantlabel11;
        private System.Windows.Forms.Label slantlabel21;
        private System.Windows.Forms.Label slantlabel12;
        private System.Windows.Forms.Label slantlabel22;
    }
}

