﻿using System.Drawing;

namespace WindowsFormsApp1
{

    /// <summary>
    /// Класс наследник от класса Fractal, реализует множество Кантора.
    /// </summary>
    public class CantorSet: Fractal
    {

        /// <summary>
        ///  Рекурсивный метод отрисовывает множество Кантора.
        /// </summary>
        /// <param name="leftPoint"> Левая точка отрезка.</param>
        /// <param name="rightPoint"> Правая точка отрезка.</param>
        /// <param name="none"> Бессмысленный параметр, добавлен из-за наследования от класса Fractal.</param>
        /// <param name="depthOfRecursion"> Глубина рекурсии на данной итерации.</param>
        public override void DrowFractal(PointF leftPoint, PointF rightPoint, PointF none, int depthOfRecursion)
        {
            if (depthOfRecursion == 0)
            {
                return;
            }
            else if (depthOfRecursion == Form1.RecursionBar)
            {
                Form1.gr.DrawLine(Form1.pen3, leftPoint, rightPoint);
                PointF x1 = new PointF(leftPoint.X, leftPoint.Y+Form1.indent);
                PointF y1 = new PointF(rightPoint.X, leftPoint.Y +Form1.indent);
                DrowFractal(x1, y1, new PointF(0, 0), depthOfRecursion - 1);
            }
            else
            {
                Form1.gr.DrawLine(Form1.pen3, leftPoint, rightPoint);
                PointF x1 = new PointF((rightPoint.X - leftPoint.X) / 3 + leftPoint.X, leftPoint.Y);
                PointF y1 = new PointF((rightPoint.X - leftPoint.X) / 3*2 + leftPoint.X, leftPoint.Y);
                Form1.gr.DrawLine(Form1.pen4, x1, y1);
                PointF x2 = new PointF(leftPoint.X, leftPoint.Y + Form1.indent);
                PointF y2 = new PointF(rightPoint.X, leftPoint.Y + Form1.indent);
                PointF x3 = new PointF(x1.X, x1.Y + Form1.indent);
                PointF y3 = new PointF(y1.X, x1.Y + Form1.indent);
                DrowFractal(x2, x3, new PointF(0, 0), depthOfRecursion - 1);
                DrowFractal(y2, y3, new PointF(0, 0), depthOfRecursion - 1);
            }
        }
    }
}
