﻿using System;
using System.Drawing;

namespace WindowsFormsApp1
{
    /// <summary>
    /// Класс наследник от класса Fractal, реализует кривую Коха.
    /// </summary>
    public class KochCurve: Fractal
    {

        /// <summary>
        /// Рекурсивный метод отрисовывает кривую Коха.
        /// </summary>
        /// <param name="leftPoint"> Левая точка отрезка.</param>
        /// <param name="rigthPoint"> Правая точка отрезка.</param>
        /// <param name="none"> Бессмысленный параметр, добавлен из-за наследования от класса Fractal.</param>
        /// <param name="depthOfRecursion"> Глубина рекурсии.</param>
        public override void DrowFractal(PointF leftPoint, PointF rigthPoint, PointF none, int depthOfRecursion)
        {
            if (depthOfRecursion == 0)
            {
                return;
            }
            else if (depthOfRecursion== Form1.RecursionBar)
            {
                Form1.gr.DrawLine(Form1.pen1, leftPoint, rigthPoint);
                DrowFractal(leftPoint, rigthPoint, new PointF(0,0), depthOfRecursion - 1);
            }
            else
            {
                PointF x1 = new PointF(leftPoint.X + (rigthPoint.X - leftPoint.X) / 3, leftPoint.Y + (rigthPoint.Y - leftPoint.Y) / 3);
                PointF y1 = new PointF(leftPoint.X + 2 * (rigthPoint.X - leftPoint.X) / 3, leftPoint.Y + 2 * (rigthPoint.Y - leftPoint.Y) / 3);
                Form1.gr.DrawLine(Form1.pen2, x1, y1);
                PointF z1 = new PointF((float)((x1.X + y1.X) / 2 + (y1.Y - x1.Y) * Math.Sqrt(3) / 2), (float)((x1.Y + y1.Y) / 2 - (y1.X-x1.X)*Math.Sqrt(3)/2));
                Form1.gr.DrawLine(Form1.pen1, x1, z1);

                Form1.gr.DrawLine(Form1.pen1, z1, y1);
                DrowFractal(x1,z1, new PointF(0, 0), depthOfRecursion - 1);
                DrowFractal(z1,y1, new PointF(0, 0), depthOfRecursion - 1);
                DrowFractal(leftPoint, x1, new PointF(0, 0), depthOfRecursion - 1);
                DrowFractal(y1, rigthPoint, new Point(0, 0), depthOfRecursion - 1);
            }
        }
    }
}
