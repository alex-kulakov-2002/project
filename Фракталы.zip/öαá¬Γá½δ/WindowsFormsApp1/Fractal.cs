﻿using System.Drawing;

namespace WindowsFormsApp1
{

    /// <summary>
    /// Абстрактный класс всех фракталов.
    /// </summary>
    public abstract class Fractal
    {
        public static int depthOfRecursion=0;

        public abstract void DrowFractal(PointF x, PointF y, PointF z, int depthOfRecursion);
    }
}
