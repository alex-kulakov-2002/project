﻿using System.Drawing;

namespace WindowsFormsApp1
{
    /// <summary>
    /// Класс наследник от класса Fractal, реализует треугольник Серпинского.
    /// </summary>
    public class SierpinskiTriangle: Fractal
    {

        /// <summary>
        /// 
        /// </summary>
        /// <param name="firstAngle"> Первый угол.</param>
        /// <param name="secondAngle"> Второй угол.</param>
        /// <param name="thirdAngle"> Третий угол.</param>
        /// <param name="depthOfRecursion"> Глубина рекурсии.</param>
        public  override void DrowFractal(PointF firstAngle, PointF secondAngle, PointF thirdAngle, int depthOfRecursion)
        {
            if (depthOfRecursion == 0)
            {
                return;
            }
            else
            {
                Form1.gr.DrawLine(Form1.pen1,firstAngle, secondAngle);
                Form1.gr.DrawLine(Form1.pen1, firstAngle, thirdAngle);
                Form1.gr.DrawLine(Form1.pen1, thirdAngle, secondAngle);
                PointF centreXY = new PointF((firstAngle.X + secondAngle.X) / 2, (firstAngle.Y + secondAngle.Y) / 2);
                PointF centreXZ = new PointF((firstAngle.X + thirdAngle.X) / 2, (firstAngle.Y + thirdAngle.Y) / 2);
                PointF centreYZ = new PointF((thirdAngle.X + secondAngle.X) / 2, (thirdAngle.Y + secondAngle.Y) / 2);
                DrowFractal(firstAngle, centreXZ, centreXY, depthOfRecursion - 1);
                DrowFractal(secondAngle, centreXY, centreYZ, depthOfRecursion - 1);
                DrowFractal(thirdAngle, centreYZ, centreXZ, depthOfRecursion - 1);
            }
        }
    }
}
