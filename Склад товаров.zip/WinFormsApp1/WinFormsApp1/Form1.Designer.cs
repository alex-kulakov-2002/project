﻿
namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.ContextMenuMakeSection = new System.Windows.Forms.ToolStripMenuItem();
            this.ContextMenuChangeSection = new System.Windows.Forms.ToolStripMenuItem();
            this.ContextMenuDeleteSection = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripClassifier = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMakeSection = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripDeleteSectin = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripChangeSection = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripOpen = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSave = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripProduct = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMakeProduct = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripDeleteProduct = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripReport = new System.Windows.Forms.ToolStripMenuItem();
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.saveFileDialog2 = new System.Windows.Forms.SaveFileDialog();
            this.toolStripReferense = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip2.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ContextMenuMakeSection,
            this.ContextMenuChangeSection,
            this.ContextMenuDeleteSection});
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            this.contextMenuStrip2.Size = new System.Drawing.Size(200, 76);
            // 
            // ContextMenuMakeSection
            // 
            this.ContextMenuMakeSection.Name = "ContextMenuMakeSection";
            this.ContextMenuMakeSection.Size = new System.Drawing.Size(199, 24);
            this.ContextMenuMakeSection.Text = "Создать раздел";
            // 
            // ContextMenuChangeSection
            // 
            this.ContextMenuChangeSection.Name = "ContextMenuChangeSection";
            this.ContextMenuChangeSection.Size = new System.Drawing.Size(199, 24);
            this.ContextMenuChangeSection.Text = "Изменить раздел";
            // 
            // ContextMenuDeleteSection
            // 
            this.ContextMenuDeleteSection.Name = "ContextMenuDeleteSection";
            this.ContextMenuDeleteSection.Size = new System.Drawing.Size(199, 24);
            this.ContextMenuDeleteSection.Text = "Удалить раздел";
            // 
            // toolStripClassifier
            // 
            this.toolStripClassifier.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMakeSection,
            this.toolStripDeleteSectin,
            this.toolStripChangeSection});
            this.toolStripClassifier.Name = "toolStripClassifier";
            this.toolStripClassifier.Size = new System.Drawing.Size(129, 24);
            this.toolStripClassifier.Text = "Классификатор";
            // 
            // toolStripMakeSection
            // 
            this.toolStripMakeSection.Name = "toolStripMakeSection";
            this.toolStripMakeSection.Size = new System.Drawing.Size(213, 26);
            this.toolStripMakeSection.Text = "Создать раздел";
            // 
            // toolStripDeleteSectin
            // 
            this.toolStripDeleteSectin.Name = "toolStripDeleteSectin";
            this.toolStripDeleteSectin.Size = new System.Drawing.Size(213, 26);
            this.toolStripDeleteSectin.Text = "Удалить раздел";
            // 
            // toolStripChangeSection
            // 
            this.toolStripChangeSection.Name = "toolStripChangeSection";
            this.toolStripChangeSection.Size = new System.Drawing.Size(213, 26);
            this.toolStripChangeSection.Text = "Изменить раздел";
            // 
            // toolStripOpen
            // 
            this.toolStripOpen.Name = "toolStripOpen";
            this.toolStripOpen.Size = new System.Drawing.Size(81, 24);
            this.toolStripOpen.Text = "Открыть";
            // 
            // toolStripSave
            // 
            this.toolStripSave.Name = "toolStripSave";
            this.toolStripSave.Size = new System.Drawing.Size(97, 24);
            this.toolStripSave.Text = "Сохранить";
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripClassifier,
            this.toolStripOpen,
            this.toolStripSave,
            this.toolStripProduct,
            this.toolStripReport,
            this.toolStripReferense});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1010, 28);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripProduct
            // 
            this.toolStripProduct.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMakeProduct,
            this.toolStripDeleteProduct});
            this.toolStripProduct.Name = "toolStripProduct";
            this.toolStripProduct.Size = new System.Drawing.Size(76, 24);
            this.toolStripProduct.Text = "Товары";
            // 
            // toolStripMakeProduct
            // 
            this.toolStripMakeProduct.Name = "toolStripMakeProduct";
            this.toolStripMakeProduct.Size = new System.Drawing.Size(192, 26);
            this.toolStripMakeProduct.Text = "Создать товар";
            // 
            // toolStripDeleteProduct
            // 
            this.toolStripDeleteProduct.Name = "toolStripDeleteProduct";
            this.toolStripDeleteProduct.Size = new System.Drawing.Size(192, 26);
            this.toolStripDeleteProduct.Text = "Удалить товар";
            // 
            // toolStripReport
            // 
            this.toolStripReport.Name = "toolStripReport";
            this.toolStripReport.Size = new System.Drawing.Size(119, 24);
            this.toolStripReport.Text = "Создать отчет";
            // 
            // treeView1
            // 
            this.treeView1.LabelEdit = true;
            this.treeView1.Location = new System.Drawing.Point(0, 31);
            this.treeView1.Name = "treeView1";
            this.treeView1.Size = new System.Drawing.Size(298, 421);
            this.treeView1.TabIndex = 2;
            this.treeView1.AfterLabelEdit += new System.Windows.Forms.NodeLabelEditEventHandler(this.treeView1_AfterLabelEdit);
            this.treeView1.DoubleClick += new System.EventHandler(this.treeView1_DoubleClick);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(304, 31);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 29;
            this.dataGridView1.Size = new System.Drawing.Size(706, 421);
            this.dataGridView1.TabIndex = 3;
            this.dataGridView1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.dataGridView1_MouseDown);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // toolStripReferense
            // 
            this.toolStripReferense.Name = "toolStripReferense";
            this.toolStripReferense.Size = new System.Drawing.Size(81, 24);
            this.toolStripReferense.Text = "Справка";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1010, 454);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.treeView1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseDown);
            this.contextMenuStrip2.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.ToolStripMenuItem ContextMenuMakeSection;
        private System.Windows.Forms.ToolStripMenuItem ContextMenuChangeSection;
        private System.Windows.Forms.ToolStripMenuItem ContextMenuDeleteSection;
        private System.Windows.Forms.ToolStripMenuItem toolStripClassifier;
        private System.Windows.Forms.ToolStripMenuItem toolStripMakeSection;
        private System.Windows.Forms.ToolStripMenuItem toolStripDeleteSectin;
        private System.Windows.Forms.ToolStripMenuItem toolStripChangeSection;
        private System.Windows.Forms.ToolStripMenuItem toolStripOpen;
        private System.Windows.Forms.ToolStripMenuItem toolStripSave;
        public System.Windows.Forms.TreeView treeView1;
        public System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripProduct;
        private System.Windows.Forms.ToolStripMenuItem toolStripMakeProduct;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ToolStripMenuItem toolStripDeleteProduct;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog2;
        private System.Windows.Forms.ToolStripMenuItem toolStripReport;
        private System.Windows.Forms.ToolStripMenuItem toolStripReferense;
    }
}

