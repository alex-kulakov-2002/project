﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace WinFormsApp1
{


    /// <summary>
    /// Класс основной формы.
    /// </summary>
    [Serializable]
    public partial class Form1 : Form
    {
        public Dictionary<TreeNode, Section> treeNodesSections= new Dictionary<TreeNode, Section>();
        public Dictionary<string, Product> products = new Dictionary<string, Product>();

        BinaryFormatter formatter = new BinaryFormatter();

        public Form1()
        {
            InitializeComponent();
            toolStripMakeSection.Click += ToolStripMakeSection_Click;
            toolStripMakeProduct.Click += ToolStripMakeProduct_Click;
            ContextMenuMakeSection.Click+= ToolStripMakeSection_Click;
            treeView1.ContextMenuStrip = contextMenuStrip2;
            ContextMenuChangeSection.Click += ContextMenuChangeSection_Click;
            ContextMenuDeleteSection.Click += ContextMenuDeleteSection_Click;
            toolStripDeleteProduct.Click += ToolStripDeleteProduct_Click;
            toolStripSave.Click += ToolStripSave_Click;
            toolStripOpen.Click += ToolStripOpen_Click;
            toolStripReport.Click += ToolStripReport_Click;
            openFileDialog1.Filter = "(*.dat)|*.dat";
            saveFileDialog1.Filter= "(*.dat)|*.dat";
            saveFileDialog2.Filter= "(*.csv)|*.csv";
            treeView1.LostFocus += TreeView1_LostFocus;
            treeView1.AfterSelect += TreeView1_AfterSelect;
            dataGridView1.SelectionChanged += DataGridView1_SelectionChanged;
            treeView1.AfterLabelEdit += TreeView1_AfterLabelEdit;
            treeView1.MouseDown += TreeView1_MouseDown;
            toolStripReferense.Click += ToolStripReferense_Click;


            ContextMenuDeleteSection.Visible = false;
            ContextMenuChangeSection.Visible = false;
            toolStripChangeSection.Visible = false;
            toolStripDeleteSectin.Visible = false;
            toolStripMakeProduct.Visible = false;
            toolStripDeleteProduct.Visible = false;
            toolStripProduct.Visible = false;
        }

        private void ToolStripReferense_Click(object sender, EventArgs e)
        {
            MessageBox.Show("В программе есть контекстное меню. Разделы создаются внутри выделнного элемента тривью (если не выбран ни одни раздел, то создаются в корне). Продукты создаются внутри выбранного раздела. Код - индентификатор продукта, это единственное уникальное поле продукта. Разделитель в отчете - точка с запятой.");
        }

        /// <summary>
        /// Метод, вызывающийся при нажатии мышью на treeView.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TreeView1_MouseDown(object sender, MouseEventArgs e)
        {
            try
            {
                if (e.Button==MouseButtons.Left && e.Clicks ==1)
                {
                    treeView1.HideSelection = true;
                    treeView1.SelectedNode = null;
                    ContextMenuDeleteSection.Visible = false;
                    ContextMenuChangeSection.Visible = false;
                    toolStripChangeSection.Visible = false;
                    toolStripDeleteSectin.Visible = false;
                    if (treeView1.SelectedNode == null)
                    {
                        if (toolStripDeleteProduct.Visible)
                            toolStripMakeProduct.Visible = false;
                        else
                        {
                            toolStripProduct.Visible = false;
                            toolStripMakeProduct.Visible = false;
                        }
                    }
                    if (dataGridView1.SelectedRows.Count == 0)
                    {
                        if (toolStripMakeProduct.Visible)
                        {
                            toolStripDeleteProduct.Visible = false;
                        }
                        else
                        {
                            toolStripProduct.Visible = false;
                            toolStripDeleteProduct.Visible = false;
                        }

                    }
                    else
                    {
                        toolStripDeleteProduct.Visible = true;
                        toolStripProduct.Visible = true;
                    }
                }
            }
            catch
            {

            }
        }


        /// <summary>
        /// Отменяет не нужные изменения названий разделов.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TreeView1_AfterLabelEdit(object sender, NodeLabelEditEventArgs e)
        {
            try
            {
                e.CancelEdit = true;
            }
            catch
            {

            }
        }


        /// <summary>
        /// Метод, вызывающийся при изменении выделения на DataGridView.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.SelectedRows.Count == 0)
                {
                    if (toolStripMakeProduct.Visible)
                    {
                        toolStripDeleteProduct.Visible = false;
                    }
                    else
                    {
                        toolStripProduct.Visible = false;
                        toolStripDeleteProduct.Visible = false;
                    }
                
                }
                else
                {
                    toolStripDeleteProduct.Visible = true;
                    toolStripProduct.Visible = true;
                }
            }
            catch
            {

            }
            
        }

        /// <summary>
        ///  Метод, делающий активными элементы управления, при выделении элемента TreeView.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TreeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            try
            {
                ContextMenuDeleteSection.Visible = true;
                ContextMenuChangeSection.Visible = true;
                toolStripChangeSection.Visible = true;
                toolStripDeleteSectin.Visible = true;
                toolStripMakeProduct.Visible = true;
                toolStripProduct.Visible = true;
            }
            catch
            {

            }

        }

        /// <summary>
        ///  Метод вызывающийся при поетере фокуса с treeView.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TreeView1_LostFocus(object sender, EventArgs e)
        {
            try
            {
                ContextMenuDeleteSection.Visible = false;
                ContextMenuChangeSection.Visible = false;
                toolStripChangeSection.Visible = false;
                toolStripDeleteSectin.Visible = false;
                if (treeView1.SelectedNode == null)
                {
                    if (toolStripDeleteProduct.Visible)
                        toolStripMakeProduct.Visible = false;
                    else
                    {
                        toolStripProduct.Visible = false;
                        toolStripMakeProduct.Visible = false;
                    }
                }
            }
            catch
            {

            }
            
        }


        /// <summary>
        ///  Метод, создающий отчет.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ToolStripReport_Click(object sender, EventArgs e)
        {
            try
            {
                if (saveFileDialog2.ShowDialog() == DialogResult.Cancel)
                {
                    return;
                }
                List<string> result = new List<string>();
                result.Add("Путь; Наименование; Код; Артикул; Остаток");
                foreach (KeyValuePair<string, Product> i in products)
                {
                    if (i.Value.remains > i.Value.minimumRemains) continue;
                    string res = "";
                    TreeNode z = i.Value.treeNode;
                    res += i.Value.treeNode.Text;
                    while (z.Parent != null)
                    {
                        res = z.Parent.Text + '/'+res;
                        z = z.Parent;
                    }
                    res += $";{i.Value.Name};{i.Value.cod};{i.Value.Article};{i.Value.remains}";
                    result.Add(res);
                }

                File.WriteAllLines(saveFileDialog2.FileName, result, Encoding.UTF8);
            }
            catch
            {

            }
        }


        /// <summary>
        ///  Метод, открывающий склад.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ToolStripOpen_Click(object sender, EventArgs e)
        {
            try
            {
                if (openFileDialog1.ShowDialog() == DialogResult.Cancel)
                {
                    return;
                }
                using (Stream fs = File.Open(openFileDialog1.FileName, FileMode.Open))
                {
                    // сериализуем весь массив people

                    object save = formatter.Deserialize(fs);
                    ForSerialize s = (ForSerialize)save;
                    products = s.products;
                    treeNodesSections = s.treeNodesSections;
                    treeView1.Nodes.Clear();
                    foreach (TreeNode i in treeNodesSections.Keys)
                    {
                        if (i.Parent == null) treeView1.Nodes.Add(i);
                    }
                }
            }
            catch
            {

            }
        }


        /// <summary>
        /// Метод, сохраняющий склад.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ToolStripSave_Click(object sender, EventArgs e)
        {
            try
            {
                ForSerialize save = new ForSerialize();
                save.products = products;
                save.treeNodesSections = treeNodesSections;
                if (saveFileDialog1.ShowDialog()== DialogResult.Cancel)
                {
                    return;
                }
                using (FileStream fs = new FileStream(saveFileDialog1.FileName, FileMode.OpenOrCreate))
                {
                    formatter.Serialize(fs, save);
                }
            }
            catch
            {

            }
        }


        /// <summary>
        /// Метод, удаляющий продукт.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ToolStripDeleteProduct_Click(object sender, EventArgs e)
        {
            try
            {
                MessageBox.Show(dataGridView1.SelectedRows.Count.ToString());
                foreach (DataGridViewRow i in dataGridView1.SelectedRows)
                {
                    Product pr= products[i.Cells[1].Value.ToString()];
                    dataGridView1.DataSource = null;
                    treeNodesSections[pr.treeNode].products.Remove(pr);
                    products.Remove(pr.cod);
                    //dataGridView1.Rows.Clear();
                    dataGridView1.DataSource = treeNodesSections[pr.treeNode].products;
                    dataGridView1.Columns[0].HeaderText = "Наименование";
                    dataGridView1.Columns[1].HeaderText = "Код";
                    dataGridView1.Columns[1].ReadOnly = true;
                    dataGridView1.Columns[2].HeaderText = "Артикул";
                    dataGridView1.Columns[3].HeaderText = "Остаток";
                    dataGridView1.Columns[4].HeaderText = "Цена";
                }
            }
            catch
            {

            }
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ContextMenuDeleteSection_Click(object sender, EventArgs e)
        {
            try
            {
                Section section = treeNodesSections[treeView1.SelectedNode];
                if (section.sections.Count>0 || section.products.Count > 0)
                {
                    MessageBox.Show("Нельзя удалять разделы, содержащие подразделы или продукты");
                    return;
                }
               if (treeView1.SelectedNode.Parent != null)
                {
                    treeView1.SelectedNode.Parent.Nodes.Remove(treeView1.SelectedNode);
                }
                else
                {
                    treeView1.Nodes.Remove(treeView1.SelectedNode);
                }
            }
            catch
            {

            }
        }

        /// <summary>
        /// Метод, создающий продукт.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ToolStripMakeProduct_Click(object sender, EventArgs e)
        {
            try
            {
                FormForProduct form = new FormForProduct(this);
                form.Show();
            }
            catch
            {

            }

        }
        
        /// <summary>
        /// Метод, изменяющий раздел.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ContextMenuChangeSection_Click(object sender, EventArgs e)
        {
            try
            {
                FormForchangeSection form = new FormForchangeSection(this);
                form.Show();
            }
            catch
            {

            }
        }

        /// <summary>
        /// Метод, создающий раздел.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ToolStripMakeSection_Click(object sender, EventArgs e)
        {
            try
            {
                FormForcreate form = new FormForcreate(this);
                form.Show();
            }
            catch
            {

            }
        }

        /// <summary>
        /// Метод, вызывающийся по нажитию на форму.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            try
            {
                treeView1.HideSelection = true;
                treeView1.SelectedNode = null;
            }
            catch
            {

            }
        }
        

        /// <summary>
        /// Метод, вызывающийся после изменения названия раздела.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void treeView1_AfterLabelEdit(object sender, NodeLabelEditEventArgs e)
        {
            try
            {
                string name = treeView1.SelectedNode.Name;
                TreeNode mainTreeNode = treeView1.SelectedNode.Parent;
                int z = 0;
                if (mainTreeNode == null)
                {
                    foreach (TreeNode i in treeView1.Nodes)
                    {
                        if (i.Text == treeView1.SelectedNode.Text)
                        {
                            z += 1;

                        }
                    }
                }
                else
                {
                    foreach (TreeNode i in mainTreeNode.Nodes)
                    {
                        if (i.Name == treeView1.SelectedNode.Text)
                        {
                            z += 1;

                        }
                    }
                }

                if (z > 1)
                {
                    treeView1.SelectedNode.Text = name;
                    MessageBox.Show("Такой раздел уже существует");
                    return;
                }
                else
                {
                    treeView1.SelectedNode.Name = treeView1.SelectedNode.Text;
                }
            }
            catch
            {

            }
        }

        /// <summary>
        /// Метод, отображающий товары в разделе.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void treeView1_DoubleClick(object sender, EventArgs e)
        {
            try
            {
                dataGridView1.DataSource = null;
                Section section = treeNodesSections[treeView1.SelectedNode];
                dataGridView1.DataSource = section.products;
                dataGridView1.Columns[0].HeaderText = "Наименование";
                dataGridView1.Columns[1].HeaderText = "Код";
                dataGridView1.Columns[1].ReadOnly = true;
                dataGridView1.Columns[2].HeaderText = "Артикул";
                dataGridView1.Columns[3].HeaderText = "Остаток";
                dataGridView1.Columns[4].HeaderText = "Цена";
                treeView1.HideSelection = true;
                treeView1.SelectedNode = null;
            }
            catch
            {

            }

        }

        /// <summary>
        /// Метод, работающий с элементами управления при нажатии на dataGridView.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dataGridView1_MouseDown(object sender, MouseEventArgs e)
        {
            try
            {
                treeView1.HideSelection = true;
                treeView1.SelectedNode = null;
                ContextMenuDeleteSection.Visible = false;
                ContextMenuChangeSection.Visible = false;
                toolStripChangeSection.Visible = false;
                toolStripDeleteSectin.Visible = false;
                if (treeView1.SelectedNode == null)
                {
                    if (toolStripDeleteProduct.Visible)
                        toolStripMakeProduct.Visible = false;
                    else
                    {
                        toolStripProduct.Visible = false;
                        toolStripMakeProduct.Visible = false;
                    }
                }
                if (dataGridView1.SelectedRows.Count == 0)
                {
                    if (toolStripMakeProduct.Visible)
                    {
                        toolStripDeleteProduct.Visible = false;
                    }
                    else
                    {
                        toolStripProduct.Visible = false;
                        toolStripDeleteProduct.Visible = false;
                    }

                }
                else
                {
                    toolStripDeleteProduct.Visible = true;
                    toolStripProduct.Visible = true;
                }
            }
            catch
            {

            }
        }
    }
}
