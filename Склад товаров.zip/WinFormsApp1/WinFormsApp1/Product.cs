﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace WinFormsApp1
{
    /// <summary>
    /// Класс продукта.
    /// </summary>
    [Serializable]
    public class Product
    {
        //Form1 form;
        string name;
        public string Name {
            get
            {
                return name;
            }
            set
            { 
                if (value == null)
                {
                    MessageBox.Show("Поле не может быть пустым");
                }
                else
                {
                    name = value;
                }
            }
        }
        public string cod { get; set; }

        string article;
        public string Article {
            get
            {
                return article;
            } 
            set
            {
                if (value == null)
                {
                    MessageBox.Show("Поле не может быть пустым");
                }
                else
                {
                    article = value;
                }
            }
        }
        public int remains { get; set;}
        int priceOfBuy { get; set; }
        public int priceOfSale { get; set; }
        public string currency;
        public string company;
        public int minimumRemains;
        public int volume;
        public int weight;
        public string tax;
        public string seller;
        public string guarantee;
        public string unitsOfMeasurement;
        public string country;
        public TreeNode treeNode;

        public Product(Form1 form, string Name, string cod, string Article, int remains, int priceOfBuy = 0, int priceOfSale = 0, string currency = "RUb", string country="",
            string company = "", int minimumRemains = 0, int volume = 0, int weight=0, string tax="", string seller="", string guarantee="" , string unitsOfMeasurement="", TreeNode treeNode=null)
        {
            this.Name = Name;
            this.cod = cod;
            this.Article = Article;
            this.remains = remains;
            this.priceOfBuy = priceOfBuy;
            this.priceOfSale = priceOfSale;
            this.currency = currency;
            this.company = company;
            this.minimumRemains = minimumRemains;
            this.volume = volume;
            this.weight = weight;
            this.tax = tax;
            this.seller = seller;
            this.guarantee = guarantee;
            this.unitsOfMeasurement = unitsOfMeasurement;
            this.country = country;
            //this.form = form;
            this.treeNode = treeNode;
            form.products[cod] = this;
        }

        public Product()
        {

        }

    }
}
