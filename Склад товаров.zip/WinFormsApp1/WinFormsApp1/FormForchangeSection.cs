﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    /// <summary>
    /// Форма, для изменения раздела.
    /// </summary>
    class FormForchangeSection : Form
    {
        private Label label1;
        private Button ChangeButton;
        private TextBox textBox1;
        Form1 mainForm;
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.ChangeButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(178, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(182, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Введите новое название";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(12, 120);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(522, 27);
            this.textBox1.TabIndex = 1;
            // 
            // ChangeButton
            // 
            this.ChangeButton.Location = new System.Drawing.Point(427, 202);
            this.ChangeButton.Name = "ChangeButton";
            this.ChangeButton.Size = new System.Drawing.Size(94, 29);
            this.ChangeButton.TabIndex = 2;
            this.ChangeButton.Text = "Изменить";
            this.ChangeButton.UseVisualStyleBackColor = true;
            this.ChangeButton.Click += new System.EventHandler(this.ChangeButton_Click);
            // 
            // FormForchangeSection
            // 
            this.ClientSize = new System.Drawing.Size(546, 243);
            this.Controls.Add(this.ChangeButton);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Name = "FormForchangeSection";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        public FormForchangeSection(Form1 mainForm)
        {
            this.mainForm = mainForm;
            InitializeComponent();
        }

        /// <summary>
        /// Метод, изменяющий раздел.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ChangeButton_Click(object sender, EventArgs e)
        {
            string name = textBox1.Text;
            TreeNode mainTreeNode = mainForm.treeView1.SelectedNode.Parent;
            int z = 0;
            if (mainTreeNode == null)
            {
                foreach (TreeNode i in mainForm.treeView1.Nodes)
                {
                    if (i.Text == name)
                    {
                        z += 1;

                    }
                }
            }
            else
            {
                foreach (TreeNode i in mainTreeNode.Nodes)
                {
                    if (i.Name == name)
                    {
                        z += 1;

                    }
                }
            }

            if (z > 0)
            {
                MessageBox.Show("Такой раздел уже существует");
                this.Close();
                return;
            }
            else
            {
                mainForm.treeView1.SelectedNode.Name = name;
                mainForm.treeView1.SelectedNode.Text = name;
            }
            this.Close();
        }
    }
}
