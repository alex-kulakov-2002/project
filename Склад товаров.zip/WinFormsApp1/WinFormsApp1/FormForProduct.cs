﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{

    /// <summary>
    /// Форма, для создания продукта.
    /// </summary>
    [Serializable]
    class FormForProduct : Form
    {
        Form1 form;

        private TabControl tabControl1;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private Label label10;
        private ComboBox comboBoxCountry;
        private TextBox textBoxCompany;
        private TextBox textBox13;
        private TextBox textBox15;
        private TextBox textBox16;
        private Label label11;
        private Label label12;
        private Label label13;
        private Label label14;
        private Label label15;
        private Label label16;
        private Label label17;
        private NumericUpDown numericUpDownMinimumRemains;
        private NumericUpDown numericUpDownRemains;
        private TextBox textBox3;
        private Label label6;
        private TextBox textBoxCod;
        private Label label5;
        private TextBox textBoxName;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private ComboBox comboBoxGuarantee;
        private TextBox textBoxSeller;
        private ComboBox comboBoxTax;
        private NumericUpDown numericUpDownWeight;
        private NumericUpDown numericUpDownVolume;
        private Label label20;
        private Label label19;
        private Label label9;
        private Label label8;
        private Label label7;
        private ComboBox comboBoxUnitsOfMeasurement;
        private Label label21;
        private ComboBox comboBoxCurrency;
        private Label label22;
        private TextBox textBoxArticle;
        private Button buttonCreateProduct;
        private Button button1CreateProduct2;
        private NumericUpDown numericUpDownPriceOfSale;
        private NumericUpDown numericUpDownPriceOfBuy;
        private Label label18;

        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.numericUpDownPriceOfSale = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownPriceOfBuy = new System.Windows.Forms.NumericUpDown();
            this.buttonCreateProduct = new System.Windows.Forms.Button();
            this.comboBoxCurrency = new System.Windows.Forms.ComboBox();
            this.label22 = new System.Windows.Forms.Label();
            this.numericUpDownMinimumRemains = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownRemains = new System.Windows.Forms.NumericUpDown();
            this.textBoxArticle = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxCod = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxName = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.comboBoxCountry = new System.Windows.Forms.ComboBox();
            this.textBoxCompany = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button1CreateProduct2 = new System.Windows.Forms.Button();
            this.comboBoxUnitsOfMeasurement = new System.Windows.Forms.ComboBox();
            this.label21 = new System.Windows.Forms.Label();
            this.comboBoxGuarantee = new System.Windows.Forms.ComboBox();
            this.textBoxSeller = new System.Windows.Forms.TextBox();
            this.comboBoxTax = new System.Windows.Forms.ComboBox();
            this.numericUpDownWeight = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownVolume = new System.Windows.Forms.NumericUpDown();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownPriceOfSale)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownPriceOfBuy)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownMinimumRemains)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownRemains)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownWeight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownVolume)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(2, 1);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(765, 482);
            this.tabControl1.TabIndex = 19;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.numericUpDownPriceOfSale);
            this.tabPage1.Controls.Add(this.numericUpDownPriceOfBuy);
            this.tabPage1.Controls.Add(this.buttonCreateProduct);
            this.tabPage1.Controls.Add(this.comboBoxCurrency);
            this.tabPage1.Controls.Add(this.label22);
            this.tabPage1.Controls.Add(this.numericUpDownMinimumRemains);
            this.tabPage1.Controls.Add(this.numericUpDownRemains);
            this.tabPage1.Controls.Add(this.textBoxArticle);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.textBoxCod);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.textBoxName);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.comboBoxCountry);
            this.tabPage1.Controls.Add(this.textBoxCompany);
            this.tabPage1.Controls.Add(this.textBox13);
            this.tabPage1.Controls.Add(this.textBox15);
            this.tabPage1.Controls.Add(this.textBox16);
            this.tabPage1.Controls.Add(this.label11);
            this.tabPage1.Controls.Add(this.label12);
            this.tabPage1.Controls.Add(this.label13);
            this.tabPage1.Controls.Add(this.label14);
            this.tabPage1.Controls.Add(this.label15);
            this.tabPage1.Controls.Add(this.label16);
            this.tabPage1.Controls.Add(this.label17);
            this.tabPage1.Controls.Add(this.label18);
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(757, 449);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Основные свойства";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // numericUpDownPriceOfSale
            // 
            this.numericUpDownPriceOfSale.Location = new System.Drawing.Point(497, 183);
            this.numericUpDownPriceOfSale.Name = "numericUpDownPriceOfSale";
            this.numericUpDownPriceOfSale.Size = new System.Drawing.Size(197, 27);
            this.numericUpDownPriceOfSale.TabIndex = 51;
            // 
            // numericUpDownPriceOfBuy
            // 
            this.numericUpDownPriceOfBuy.Location = new System.Drawing.Point(141, 183);
            this.numericUpDownPriceOfBuy.Name = "numericUpDownPriceOfBuy";
            this.numericUpDownPriceOfBuy.Size = new System.Drawing.Size(172, 27);
            this.numericUpDownPriceOfBuy.TabIndex = 50;
            // 
            // buttonCreateProduct
            // 
            this.buttonCreateProduct.Location = new System.Drawing.Point(625, 409);
            this.buttonCreateProduct.Name = "buttonCreateProduct";
            this.buttonCreateProduct.Size = new System.Drawing.Size(94, 29);
            this.buttonCreateProduct.TabIndex = 20;
            this.buttonCreateProduct.Text = "Создать";
            this.buttonCreateProduct.UseVisualStyleBackColor = true;
            this.buttonCreateProduct.Click += new System.EventHandler(this.buttonCreateProduct_Click);
            // 
            // comboBoxCurrency
            // 
            this.comboBoxCurrency.FormattingEnabled = true;
            this.comboBoxCurrency.Items.AddRange(new object[] {
            "RUB",
            "USD",
            "EUR",
            "GBP",
            "JPY"});
            this.comboBoxCurrency.Location = new System.Drawing.Point(141, 243);
            this.comboBoxCurrency.Name = "comboBoxCurrency";
            this.comboBoxCurrency.Size = new System.Drawing.Size(172, 28);
            this.comboBoxCurrency.TabIndex = 49;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(23, 243);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(63, 20);
            this.label22.TabIndex = 48;
            this.label22.Text = "Валюта:";
            // 
            // numericUpDownMinimumRemains
            // 
            this.numericUpDownMinimumRemains.Location = new System.Drawing.Point(497, 356);
            this.numericUpDownMinimumRemains.Name = "numericUpDownMinimumRemains";
            this.numericUpDownMinimumRemains.Size = new System.Drawing.Size(197, 27);
            this.numericUpDownMinimumRemains.TabIndex = 47;
            // 
            // numericUpDownRemains
            // 
            this.numericUpDownRemains.Location = new System.Drawing.Point(141, 356);
            this.numericUpDownRemains.Name = "numericUpDownRemains";
            this.numericUpDownRemains.Size = new System.Drawing.Size(172, 27);
            this.numericUpDownRemains.TabIndex = 46;
            // 
            // textBoxArticle
            // 
            this.textBoxArticle.Location = new System.Drawing.Point(497, 130);
            this.textBoxArticle.Name = "textBoxArticle";
            this.textBoxArticle.Size = new System.Drawing.Size(197, 27);
            this.textBoxArticle.TabIndex = 45;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(319, 131);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(74, 20);
            this.label6.TabIndex = 44;
            this.label6.Text = "*Артикул:";
            // 
            // textBoxCod
            // 
            this.textBoxCod.Location = new System.Drawing.Point(141, 130);
            this.textBoxCod.Name = "textBoxCod";
            this.textBoxCod.Size = new System.Drawing.Size(172, 27);
            this.textBoxCod.TabIndex = 43;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(23, 130);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 20);
            this.label5.TabIndex = 42;
            this.label5.Text = "*Код:";
            // 
            // textBoxName
            // 
            this.textBoxName.Location = new System.Drawing.Point(109, 68);
            this.textBoxName.Name = "textBoxName";
            this.textBoxName.Size = new System.Drawing.Size(585, 27);
            this.textBoxName.TabIndex = 41;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(23, 68);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 20);
            this.label4.TabIndex = 40;
            this.label4.Text = "*Название:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(23, 356);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 20);
            this.label3.TabIndex = 39;
            this.label3.Text = "*Остаток:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(23, 292);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 20);
            this.label2.TabIndex = 38;
            this.label2.Text = "Фирма:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(23, 185);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 20);
            this.label1.TabIndex = 37;
            this.label1.Text = "Цена закупки:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(-234, -88);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(125, 20);
            this.label10.TabIndex = 19;
            this.label10.Text = "*Наименование:";
            // 
            // comboBoxCountry
            // 
            this.comboBoxCountry.FormattingEnabled = true;
            this.comboBoxCountry.Items.AddRange(new object[] {
            "Австралия",
            "Австрия",
            "Азербайджан",
            "Акротири",
            "Албания",
            "Алжир",
            "Американское Самоа",
            "Ангилья",
            "Ангола",
            "Андорра",
            "Антигуа и Барбуда",
            "Аргентина",
            "Армения",
            "Аруба",
            "Афганистан",
            "Багамские Острова",
            "Бангладеш",
            "Барбадос",
            "Бахрейн",
            "Белиз",
            "Белоруссия",
            "Бельгия",
            "Бенин",
            "Бермудские Острова",
            "Болгария",
            "Боливия",
            "Босния и Герцеговина",
            "Ботсвана",
            "Бразилия",
            "Британская территория в Индийском океане",
            "Британские Виргинские острова",
            "Бруней",
            "Буркина-Фасо",
            "Бурунди",
            "Бутан",
            "Вануату",
            "Ватикан",
            "Великобритания",
            "Венгрия",
            "Венесуэла",
            "Виргинские Острова",
            "Восточный Тимор",
            "Вьетнам",
            "Габон",
            "Гаити",
            "Гайана",
            "Гамбия",
            "Гана",
            "Гваделупа",
            "Гватемала",
            "Гвинея",
            "Гвинея-Бисау",
            "Германия",
            "Гернси",
            "Гибралтар",
            "Гондурас",
            "Гонконг",
            "Гренада",
            "Гренландия",
            "Греция",
            "Грузия",
            "Гуам",
            "Дания",
            "Декелия",
            "Демократическая Республика Конго",
            "Джерси",
            "Джибути",
            "Доминика",
            "Доминиканская Республика",
            "Египет",
            "Замбия",
            "Западная Сахара",
            "Зимбабве",
            "Израиль",
            "Индия",
            "Индонезия",
            "Иордания",
            "Ирак",
            "Иран",
            "Ирландия",
            "Исландия",
            "Испания",
            "Италия",
            "Йемен",
            "Кабо-Верде",
            "Казахстан",
            "Каймановы острова",
            "Камбоджа",
            "Камерун",
            "Канада",
            "Катар",
            "Кения",
            "Кипр",
            "Киргизия",
            "Кирибати",
            "Китай",
            "Кокосовые острова",
            "Колумбия",
            "Коморы",
            "Косово",
            "Коста-Рика",
            "Кот-д\'Ивуар",
            "Куба",
            "Кувейт",
            "Кюрасао",
            "Лаос",
            "Латвия",
            "Лесото",
            "Либерия",
            "Ливан",
            "Ливия",
            "Литва",
            "Лихтенштейн",
            "Люксембург",
            "Маврикий",
            "Мавритания",
            "Мадагаскар",
            "Майотта",
            "Макао",
            "Македония",
            "Малави",
            "Малайзия",
            "Мали",
            "Мальдивы",
            "Мальта",
            "Марокко",
            "Мартиника",
            "Маршалловы Острова",
            "Мексика",
            "Микронезия",
            "Мозамбик",
            "Молдова",
            "Монако",
            "Монголия",
            "Монтсератт",
            "Мьянма",
            "Намибия",
            "Науру",
            "Непал",
            "Нигер",
            "Нигерия",
            "Нидерландские Антильские острова",
            "Нидерланды",
            "Никарагуа",
            "Ниуэ",
            "Новая Зеландия",
            "Новая Каледония",
            "Норвегия",
            "Объединенные Арабские Эмираты",
            "Оман",
            "Остров Буве",
            "Остров Клиппертон",
            "Остров Мэн",
            "Остров Навасса",
            "Остров Норфолк",
            "Остров Рождества",
            "Остров Святой Елены, Остров Вознесения, и Тристан-да-Кунья",
            "Остров Уэйк",
            "Остров Херд и острова Макдональд",
            "Острова Ашмор и Картье",
            "Острова Кораллового моря",
            "Острова Кука",
            "Острова Питкэрн",
            "Пакистан",
            "Палау",
            "Панама",
            "Папуа - Новая Гвинея",
            "Парагвай",
            "Перу",
            "Польша",
            "Португалия",
            "Пуэрто-Рико",
            "Республика Конго",
            "Реюньон",
            "Россия",
            "Руанда",
            "Румыния",
            "Самоа",
            "Сан-Марино",
            "Сан-Томе и Принсипи",
            "Саудовская Аравия",
            "Свазиленд",
            "Северная Корея",
            "Северные Марианские острова",
            "Сейшельские Острова",
            "Сен-Бартелеми",
            "Сен-Мартен",
            "Сен-Пьер и Микелон",
            "Сенегал",
            "Сент-Винсент и Гренадины",
            "Сент-Китс и Невис",
            "Сент-Люсия",
            "Сербия",
            "Сингапур",
            "Синт-Мартен",
            "Сирия",
            "Словакия",
            "Словения",
            "Соединенные Штаты Америки",
            "Соломоновы Острова",
            "Сомали",
            "Судан",
            "Суринам",
            "Сьерра-Леоне",
            "Таджикистан",
            "Таиланд",
            "Тайвань",
            "Танзания",
            "Теркс и Кайкос",
            "Того",
            "Токелау",
            "Тонга",
            "Тринидад и Тобаго",
            "Тувалу",
            "Тунис",
            "Туркменистан",
            "Турция",
            "Уганда",
            "Узбекистан",
            "Украина",
            "Уоллис и Футуна",
            "Уругвай",
            "Фарерские острова",
            "Фиджи",
            "Филиппины",
            "Финляндия",
            "Фолклендские острова",
            "Франция",
            "Французская Гвиана",
            "Французская Полинезия",
            "Французские Южные и Антарктические территории",
            "Хорватия",
            "Центральноафриканская Республика",
            "Чад",
            "Черногория",
            "Чехия",
            "Чили",
            "Швейцария",
            "Швеция",
            "Шпицберген",
            "Шри-Ланка",
            "Эквадор",
            "Экваториальная Гвинея",
            "Эль-Сальвадор",
            "Эритрея",
            "Эстония",
            "Эфиопия",
            "Южная Африка",
            "Южная Георгия и Южные Сандвичевы острова",
            "Южная Корея",
            "Южный Судан",
            "Ямайка",
            "Ян-Майен",
            "Япония"});
            this.comboBoxCountry.Location = new System.Drawing.Point(497, 292);
            this.comboBoxCountry.Name = "comboBoxCountry";
            this.comboBoxCountry.Size = new System.Drawing.Size(197, 28);
            this.comboBoxCountry.TabIndex = 36;
            // 
            // textBoxCompany
            // 
            this.textBoxCompany.Location = new System.Drawing.Point(141, 292);
            this.textBoxCompany.Name = "textBoxCompany";
            this.textBoxCompany.Size = new System.Drawing.Size(172, 27);
            this.textBoxCompany.TabIndex = 34;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(279, -39);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(197, 27);
            this.textBox13.TabIndex = 31;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(-77, -39);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(172, 27);
            this.textBox15.TabIndex = 29;
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(-77, -91);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(553, 27);
            this.textBox16.TabIndex = 28;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(319, 295);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(61, 20);
            this.label11.TabIndex = 27;
            this.label11.Text = "Страна:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(319, 356);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(172, 20);
            this.label12.TabIndex = 26;
            this.label12.Text = "Минимальный остаток:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(-234, 159);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(143, 20);
            this.label13.TabIndex = 25;
            this.label13.Text = "*Остаток на складе:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(-234, 94);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(60, 20);
            this.label14.TabIndex = 24;
            this.label14.Text = "Фирма:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(319, 185);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(115, 20);
            this.label15.TabIndex = 23;
            this.label15.Text = "Цена продажи:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(-234, 27);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(106, 20);
            this.label16.TabIndex = 22;
            this.label16.Text = "Цена закупки:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(101, -39);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(68, 20);
            this.label17.TabIndex = 21;
            this.label17.Text = "Артикул:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(-234, -39);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(44, 20);
            this.label18.TabIndex = 20;
            this.label18.Text = "*Код:";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.button1CreateProduct2);
            this.tabPage2.Controls.Add(this.comboBoxUnitsOfMeasurement);
            this.tabPage2.Controls.Add(this.label21);
            this.tabPage2.Controls.Add(this.comboBoxGuarantee);
            this.tabPage2.Controls.Add(this.textBoxSeller);
            this.tabPage2.Controls.Add(this.comboBoxTax);
            this.tabPage2.Controls.Add(this.numericUpDownWeight);
            this.tabPage2.Controls.Add(this.numericUpDownVolume);
            this.tabPage2.Controls.Add(this.label20);
            this.tabPage2.Controls.Add(this.label19);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Location = new System.Drawing.Point(4, 29);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(757, 449);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Дополнительные свойства";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // button1CreateProduct2
            // 
            this.button1CreateProduct2.Location = new System.Drawing.Point(627, 409);
            this.button1CreateProduct2.Name = "button1CreateProduct2";
            this.button1CreateProduct2.Size = new System.Drawing.Size(94, 29);
            this.button1CreateProduct2.TabIndex = 12;
            this.button1CreateProduct2.Text = "Создать";
            this.button1CreateProduct2.UseVisualStyleBackColor = true;
            this.button1CreateProduct2.Click += new System.EventHandler(this.buttonCreateProduct_Click);
            // 
            // comboBoxUnitsOfMeasurement
            // 
            this.comboBoxUnitsOfMeasurement.FormattingEnabled = true;
            this.comboBoxUnitsOfMeasurement.Items.AddRange(new object[] {
            "10^3 м^2",
            "10^3 т",
            "10^6 м3",
            "а",
            "блок",
            "БРТ",
            "г",
            "га",
            "гг",
            "гл",
            "г; лет",
            "дек",
            "деслет",
            "дл",
            "дм",
            "дм2",
            "дюйм",
            "дюйм2",
            "дюйм3",
            "кар",
            "кварт",
            "кг",
            "км; 10^3 м",
            "км2",
            "л; дм3",
            "м",
            "м2",
            "м3",
            "мг",
            "мес",
            "миля",
            "Мин",
            "мл",
            "мм",
            "Мм; 10^6 м",
            "мм2",
            "мм3",
            "нед",
            "пог. м",
            "полгода",
            "рулон",
            "с",
            "сг",
            "см",
            "см2",
            "см3; мл",
            "сут; дн",
            "т",
            "т грп",
            "фут",
            "фут2",
            "фут3",
            "ц",
            "ч",
            "шт",
            "ярд",
            "ярд2",
            "ярд3",
            "ящ"});
            this.comboBoxUnitsOfMeasurement.Location = new System.Drawing.Point(233, 337);
            this.comboBoxUnitsOfMeasurement.Name = "comboBoxUnitsOfMeasurement";
            this.comboBoxUnitsOfMeasurement.Size = new System.Drawing.Size(151, 28);
            this.comboBoxUnitsOfMeasurement.TabIndex = 11;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(15, 337);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(157, 20);
            this.label21.TabIndex = 10;
            this.label21.Text = "Единицы измерения:";
            // 
            // comboBoxGuarantee
            // 
            this.comboBoxGuarantee.FormattingEnabled = true;
            this.comboBoxGuarantee.Items.AddRange(new object[] {
            "Нет гарантии",
            "1 неделя",
            "2 недели",
            "Месяц",
            "3 месяца",
            "Полгода",
            "Год",
            "2 года",
            "3 года",
            "5 лет",
            "10 лет"});
            this.comboBoxGuarantee.Location = new System.Drawing.Point(233, 279);
            this.comboBoxGuarantee.Name = "comboBoxGuarantee";
            this.comboBoxGuarantee.Size = new System.Drawing.Size(151, 28);
            this.comboBoxGuarantee.TabIndex = 9;
            // 
            // textBoxSeller
            // 
            this.textBoxSeller.Location = new System.Drawing.Point(234, 217);
            this.textBoxSeller.Name = "textBoxSeller";
            this.textBoxSeller.Size = new System.Drawing.Size(151, 27);
            this.textBoxSeller.TabIndex = 8;
            // 
            // comboBoxTax
            // 
            this.comboBoxTax.FormattingEnabled = true;
            this.comboBoxTax.Items.AddRange(new object[] {
            "ОСНО",
            "УСН",
            "ЕНВД",
            "ЕСХН",
            "ПСН"});
            this.comboBoxTax.Location = new System.Drawing.Point(234, 150);
            this.comboBoxTax.Name = "comboBoxTax";
            this.comboBoxTax.Size = new System.Drawing.Size(151, 28);
            this.comboBoxTax.TabIndex = 7;
            // 
            // numericUpDownWeight
            // 
            this.numericUpDownWeight.Location = new System.Drawing.Point(234, 94);
            this.numericUpDownWeight.Name = "numericUpDownWeight";
            this.numericUpDownWeight.Size = new System.Drawing.Size(150, 27);
            this.numericUpDownWeight.TabIndex = 6;
            // 
            // numericUpDownVolume
            // 
            this.numericUpDownVolume.Location = new System.Drawing.Point(234, 26);
            this.numericUpDownVolume.Name = "numericUpDownVolume";
            this.numericUpDownVolume.Size = new System.Drawing.Size(150, 27);
            this.numericUpDownVolume.TabIndex = 5;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(15, 282);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(76, 20);
            this.label20.TabIndex = 4;
            this.label20.Text = "Гарантия:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(15, 220);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(89, 20);
            this.label19.TabIndex = 3;
            this.label19.Text = "Поставщик:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(15, 153);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(203, 20);
            this.label9.TabIndex = 2;
            this.label9.Text = "Система налогообложения:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(15, 96);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(55, 20);
            this.label8.TabIndex = 1;
            this.label8.Text = "Масса:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(15, 29);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(60, 20);
            this.label7.TabIndex = 0;
            this.label7.Text = "Объем:";
            // 
            // FormForProduct
            // 
            this.ClientSize = new System.Drawing.Size(767, 480);
            this.Controls.Add(this.tabControl1);
            this.Name = "FormForProduct";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownPriceOfSale)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownPriceOfBuy)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownMinimumRemains)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownRemains)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownWeight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownVolume)).EndInit();
            this.ResumeLayout(false);

        }

        public FormForProduct(Form1 form)
        {
            InitializeComponent();
            this.form = form;
        }


        /// <summary>
        /// Метод, создания продукта.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonCreateProduct_Click(object sender, EventArgs e)
        {
            TreeNode treeNode = form.treeView1.SelectedNode;
            string name = textBoxName.Text;
            string cod = textBoxCod.Text;
            string article=textBoxArticle.Text;
            int remains = (int)numericUpDownRemains.Value;
            if (name == "" || cod == "" || article=="")
            {
                MessageBox.Show("Заданы не все обязательные поля (к обязательным относятся: наименование, код, артикул, остаток)");
                return;
            }
            if (form.products.ContainsKey(cod))
            {
                MessageBox.Show("У каждого товара должен быть свой собственный уникальный код");
                return;
            }
            
            int priceOfBuy=(int) numericUpDownPriceOfBuy.Value;
            int priceOfSale=(int) numericUpDownPriceOfSale.Value;
            string currency=comboBoxCurrency.Text;
            string country= comboBoxCountry.Text;
            string company=textBoxCompany.Text;
            int minimumRemains=(int)numericUpDownMinimumRemains.Value;
            int volume=(int)numericUpDownVolume.Value;
            int weight=(int)numericUpDownWeight.Value;
            string tax=comboBoxTax.Text;
            string seller=textBoxSeller.Text;
            string guarantee=comboBoxGuarantee.Text;
            string unitsOfMeasurement=comboBoxUnitsOfMeasurement.Text;
            Product product = new Product(form, name, cod, article, remains, priceOfBuy, priceOfSale, currency, country, 
                company, minimumRemains, volume, weight, tax, seller, guarantee, unitsOfMeasurement, treeNode);
            form.treeNodesSections[treeNode].products.Add(product);
            this.Close();
        }

    }
}
