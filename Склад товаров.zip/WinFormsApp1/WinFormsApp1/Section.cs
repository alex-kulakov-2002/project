﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace WinFormsApp1
{
    /// <summary>
    /// Класс раздела.
    /// </summary>
    [Serializable]
    public class Section
    {
        public List<Product> products = new List<Product>();
        public List<Section> sections = new List<Section>();
        TreeNode treeNode;

        public Section(TreeNode treeNode)
        {
            this.treeNode = treeNode;
        }
        public Section()
        {

        }

    }
}
