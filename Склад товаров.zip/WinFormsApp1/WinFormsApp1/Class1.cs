﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;
using System.IO;


namespace WinFormsApp1
{

    /// <summary>
    /// Класс нужный для сериализации.
    /// </summary>

    [Serializable]
    public class ForSerialize
    {
        //public List<TreeNode> treeNodesSectionsTreeNode= new List<TreeNode>();
        //public List<Section> treeNodesSectionsSection= new List<Section>();
        //public List<string> productsCod= new List<string>();
        //public List<Product> productsProduct= new List<Product>();

        public Dictionary<TreeNode, Section> treeNodesSections = new Dictionary<TreeNode, Section>();
        public Dictionary<string, Product> products = new Dictionary<string, Product>();


        //public ForSerialize(Dictionary<TreeNode, Section> treeNodesSections, Dictionary<string, Product> products)
        //{
        //    foreach (KeyValuePair<TreeNode, Section> i in treeNodesSections)
        //    {
        //        treeNodesSectionsTreeNode.Add(i.Key);
        //        treeNodesSectionsSection.Add(i.Value);
        //    }
        //    foreach(KeyValuePair<string, Product> i in products)
        //    {
        //        productsCod.Add(i.Key);
        //        productsProduct.Add(i.Value);
        //    }
        //}

        public ForSerialize()
        {

        }

    }
}
