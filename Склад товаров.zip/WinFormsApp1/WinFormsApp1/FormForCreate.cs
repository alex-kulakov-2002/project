﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{

    /// <summary>
    /// Форма для создания раздела.
    /// </summary>
    [Serializable]
    class FormForcreate : Form
    {
        private TextBox textBox1;
        private Button buttonForCreat;
        private Label label1;
        Form1 mainForm;

        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.buttonForCreat = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(130, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(195, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Введите название раздела";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(12, 83);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(444, 27);
            this.textBox1.TabIndex = 1;
            // 
            // buttonForCreat
            // 
            this.buttonForCreat.Location = new System.Drawing.Point(346, 148);
            this.buttonForCreat.Name = "buttonForCreat";
            this.buttonForCreat.Size = new System.Drawing.Size(94, 29);
            this.buttonForCreat.TabIndex = 2;
            this.buttonForCreat.Text = "Создать";
            this.buttonForCreat.UseVisualStyleBackColor = true;
            this.buttonForCreat.Click += new System.EventHandler(this.buttonForCreate_Click);
            // 
            // FormForcreate
            // 
            this.ClientSize = new System.Drawing.Size(468, 209);
            this.Controls.Add(this.buttonForCreat);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Name = "FormForcreate";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        public FormForcreate(Form1 mainForm)
        {
            this.mainForm = mainForm;
            InitializeComponent();
            //foreach (TreeNode i in mainForm.treeView1.Nodes)
            //{
            //    comboBox1.Items.Add(i.Text);
            //    MakeCombobox(i);
            //}
        }

        //private void MakeCombobox(TreeNode treenode)
        //{
        //    foreach (TreeNode i in treenode.Nodes)
        //    {
        //        comboBox1.Items.Add(i.Text);
        //        MakeCombobox(i);
        //    }
        //}

        //private void MakeTreeNode(TreeNode treenode, string name, string mainSection)
        //{
        //    if (treenode.Text == mainSection)
        //    {
        //        treenode.Nodes.Add(name, name);
        //    }
        //    else
        //    {
        //        foreach (TreeNode i in treenode.Nodes) MakeTreeNode(i, name, mainSection);
        //    }
        //}


        /// <summary>
        /// Метод, создающий раздел.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonForCreate_Click(object sender, EventArgs e)
        {
            string name = textBox1.Text;
            
            
            if (mainForm.treeView1.SelectedNode != null)
            {
                
                TreeNode treeNode = mainForm.treeView1.SelectedNode;
                foreach (TreeNode i in treeNode.Nodes)
                {
                    if (i.Text == name)
                    {
                        MessageBox.Show("Такой раздел уже существует");
                        return;
                    }
                }
                TreeNode treenode = new TreeNode(name);
                treeNode.Nodes.Add(treenode);
                Section section = new Section(treenode);
                mainForm.treeNodesSections[treenode] = new Section(treenode);
                mainForm.treeNodesSections[treeNode].sections.Add(mainForm.treeNodesSections[treenode]);
            }
            else
            {
                foreach (TreeNode i in mainForm.treeView1.Nodes)
                {
                    if (i.Text == name)
                    {
                        MessageBox.Show("Такой раздел уже существует");
                        return;
                    }
                }
                TreeNode treenode = new TreeNode(name);
                mainForm.treeView1.Nodes.Add(treenode);
                mainForm.treeNodesSections[treenode] = new Section(treenode);
            }
            this.Close();
        }

    }
}
