﻿using System;
using ClassLibrary1;
using System.IO;
using System.Xml.Serialization;
using System.Collections.Generic;

namespace ConsoleApp1
{


    /* В этой части кода встречаются достаточно длинные методы,
     * но декомпозиция нужна для улучшения читабельности кода(чтобы человеку не надо было помнить, что было в начале метода)
     * при использовании case каждый блок не связан с другим, то есть при разборе в коде не будет необходимости помнить весь метод.
     * Поэтому выделение блоков case в методы во-первых бессмысленно, а во вторых может нарушить логику программы. */
    class Program
    {
        static void CurrentDomain_ProcessExit(object sender, EventArgs e)
        {
            SerializeMetod();
        }
        static void Main(string[] args)
        {
            try
            {
                AppDomain.CurrentDomain.ProcessExit += new EventHandler(CurrentDomain_ProcessExit);
            }
            catch
            {

            }

            DeserializeMetod();

            while (true)
            {
                Clear();
                Console.WriteLine("Выберите один из вариантов:" + Environment.NewLine +
                    "0. Завершить программу" + Environment.NewLine +
                    "1. Работа с пользователями" + Environment.NewLine +
                    "2. Работа с проектами");
                switch (Chose(0, 2))
                {
                    case 0:
                        SerializeMetod();

                        Environment.Exit(0);
                        break;
                    case 1:
                        try
                        {
                            WorkWithUsers();
                        }
                        catch
                        {

                        }
                        break;
                    case 2:
                        try
                        {
                            WorkWithProjects();
                        }
                        catch
                        {

                        }
                        break;
                }
            }
        }

        /// <summary>
        /// Метод, осуществляющий десериализацию.
        /// </summary>
        private static void DeserializeMetod()
        {
            try
            {
                Users us;
                XmlSerializer xmlUsers = new XmlSerializer(typeof(Users));
                using (FileStream fs = new FileStream("User.xml", FileMode.OpenOrCreate))
                {

                    us = (Users)xmlUsers.Deserialize(fs);

                }
                User.users = us.users;
            }
            catch
            {

            }
            try
            {
                Projects pr;
                XmlSerializer xml = new XmlSerializer(typeof(Projects));
                using (FileStream fs = new FileStream("Project.xml", FileMode.OpenOrCreate))
                {
                    pr = (Projects)xml.Deserialize(fs);
                }
                Project.projects = pr.projects;
            }
            catch
            {

            }
        }

        /// <summary>
        /// Метод, осуществляющий сериализацию.
        /// </summary>
        private static void SerializeMetod()
        {
            try
            {
                Users us1 = new Users();
                us1.users = User.users;
                XmlSerializer xmlUsers1 = new XmlSerializer(typeof(Users));
                using (FileStream fs = new FileStream("User.xml", FileMode.OpenOrCreate))
                {
                    xmlUsers1.Serialize(fs, us1);
                }
            }
            catch
            {

            }

            try
            {
                Projects pr1 = new Projects();
                pr1.projects = Project.projects;
                XmlSerializer xml1 = new XmlSerializer(typeof(Projects));
                using (FileStream fs = new FileStream("Project.xml", FileMode.OpenOrCreate))
                {
                    xml1.Serialize(fs, pr1);
                }
            }
            catch
            {

            }
        }

        /// <summary>
        /// Метод, осуществляющий работу с проектами.
        /// </summary>
        static void WorkWithProjects()
        {
            Clear();
            Console.WriteLine("Выберите один из вариантов:" + Environment.NewLine +
                "1. Просмотр проектов" + Environment.NewLine +
                "2. Создание проекта" + Environment.NewLine +
                "3. Изменение названия проекта" + Environment.NewLine +
                "4. Удаление проекта" + Environment.NewLine +
                "5. Выбор проекта и работа с ним");
            switch (Chose(1, 5))
            {
                case 1:
                    PrintProjects();
                    break;
                case 2:
                    CreatProject();
                    break;
                case 3:
                    if (Project.projects.Count == 0)
                    {
                        Console.WriteLine("Не создано ни одного проекта, для возвращения в меню нажмите любую клавишу");
                        Console.ReadLine();
                        break;
                    }
                    
                     
                    Console.WriteLine("Выберите проект, название которого вы хотите изменить");
                    Console.WriteLine(Project.PrintProjects());
                    int numberOfproject = Chose(1, Project.projects.Count);
                    Console.Write("Введите новое название: ");
                    Project.projects[numberOfproject - 1].name = Console.ReadLine();
                    Console.WriteLine("Название изменено, для возвращения в меню нажмите любую клавишу");
                    Console.ReadLine();
                    break;
                    
                case 4:
                    if (Project.projects.Count == 0)
                    {
                        Console.WriteLine("Не создано ни одного проекта, для возвращения в меню нажмите любую клавишу");
                        Console.ReadLine();
                        break;
                    }
                    Console.WriteLine(Project.PrintProjects());
                    Console.WriteLine("Выберите проект, который вы хотите удалить");
                    numberOfproject = Chose(1, Project.projects.Count);
                    Project.DeleteProject(numberOfproject-1);
                    Console.WriteLine("Проект удален, для возвращения в меню нажмите любую клавишу");
                    Console.ReadLine();
                    break;
                case 5:
                    if (Project.projects.Count == 0)
                    {
                        Console.WriteLine("Не создано ни одного проекта, для возвращения в меню нажмите любую клавишу");
                        Console.ReadLine();
                        break;
                    }
                    Console.WriteLine(Project.PrintProjects());
                    Console.WriteLine("Выберите проект");
                    numberOfproject = Chose(1, Project.projects.Count);
                    WorkWithProblems(numberOfproject-1);
                    break;
            }
        }

        /// <summary>
        /// Метод, создающий проект.
        /// </summary>
        private static void CreatProject()
        {
            Console.WriteLine("Введите название проекта");
            string projectName = Console.ReadLine();
            new Project(projectName);
            Console.WriteLine("Проект добавлен, для возвращения в меню нажмите любую клавишу");
            Console.ReadLine();
        }

        /// <summary>
        /// Метод, выводящий список проектов.
        /// </summary>
        private static void PrintProjects()
        {
            Console.WriteLine(Project.PrintProjects());
            Console.WriteLine("Для возвращения в меню нажмите любую клавишу");
            Console.ReadLine();
        }

        /// <summary>
        /// Метод, осуществляющий работу с задачами.
        /// </summary>
        /// <param name="numberOfProject"> Номер проекта, с задачами которого будет осуществляться работа. </param>
        static void WorkWithProblems(int numberOfProject)
        {
            while (true)
            {
                Clear();
                Console.WriteLine("0. Вернуться в меню" + Environment.NewLine +
                    "1. Просмотреть задачи" + Environment.NewLine +
                    "2. Добавить новую задачу" + Environment.NewLine +
                    "3. Выбрать задачу для работы с ней" + Environment.NewLine +
                    "4. Группировка задач по статусу");
                switch (Chose(0, 4))
                {
                    case 0:
                        return;
                    case 1:
                        PrintProblems(numberOfProject);
                        break;
                    case 2:
                        Console.WriteLine("Введите название задачи");
                        string nameOfProblem = Console.ReadLine();
                        NonCorrectType:
                        Console.Write("Введите тип задачи: ");
                        DateTime dateOfCreat = DateTime.Now;
                        switch (Console.ReadLine())
                        {
                            case "Epic":
                                if (Project.projects[numberOfProject].AddProblem(new Epic(nameOfProblem, dateOfCreat)))
                                {
                                    Console.WriteLine("Задача добавлена");
                                    break;
                                }
                                Console.WriteLine("Достигнуто максимальное число задач");
                                break;
                            case "Task":
                                if (Project.projects[numberOfProject].AddProblem(new Task(nameOfProblem, dateOfCreat)))
                                {
                                    Console.WriteLine("Задача добавлена");
                                    break;
                                }
                                Console.WriteLine("Достигнуто максимальное число задач");
                                break;
                            case "Story":
                                if (Project.projects[numberOfProject].AddProblem(new Story(nameOfProblem, dateOfCreat)))
                                {
                                    Console.WriteLine("Задача добавлена");
                                    break;
                                }
                                Console.WriteLine("Достигнуто максимальное число задач");
                                break;
                            case "Bug":
                                if (Project.projects[numberOfProject].AddProblem(new Bug(nameOfProblem, dateOfCreat)))
                                {
                                    Console.WriteLine("Задача добавлена");
                                    break;
                                }
                                Console.WriteLine("Достигнуто максимальное число задач");
                                break;
                            default:
                                Console.WriteLine("Некорректный тип");
                                goto NonCorrectType;
                        }
                        Console.WriteLine("Для перехода к меню проекта нажмите любую клавишу");
                        Console.ReadLine();
                        break;
                    case 3:
                        if (Project.projects[numberOfProject].problems.Count == 0)
                        {
                            Console.WriteLine("В проекте нет ни одной задачи, для перехода в меню проекта нажмите любую клавишу");
                            Console.ReadLine();
                            break;
                        }
                        ChoseProblem(numberOfProject);

                        break;
                    case 4:
                        Groupping (numberOfProject);
                        break;
                }
            }

        }

        /// <summary>
        /// Метод, группирующий задачи по статусу.
        /// </summary>
        /// <param name="numberOfProject"> Номер выбранного проекта. </param>
        private static void Groupping(int numberOfProject)
        {
            Project.projects[numberOfProject].Groupping();
            Console.WriteLine("Задачи сгруппированы по статусу");
            Console.WriteLine("Для перехода в меню проекта нажмите любую клавишу");
            Console.ReadLine();
        }

        /// <summary>
        /// Метод, осуществляющий выбор задачи.
        /// </summary>
        /// <param name="numberOfProject"> Номер выбранного проекта. </param>
        private static void ChoseProblem(int numberOfProject)
        {
            Console.WriteLine(Project.projects[numberOfProject].PrintProblems());
            Console.WriteLine("Введите номер задачи");
            int numberOfProblem = Chose(1, Project.projects[numberOfProject].problems.Count);
            if (Project.projects[numberOfProject].problems[numberOfProblem - 1].GetType().ToString().Split('.')[1] == "Epic")
            {
                WorkWithEpic(numberOfProject, numberOfProblem - 1);
            }
            else
            {
                WorkWithSelectProblem(numberOfProject, numberOfProblem - 1);
            }
        }

        /// <summary>
        /// Метод, осуществляющий вывод задач на консоль.
        /// </summary>
        /// <param name="numberOfProject"> Номер выбранного проекта. </param>
        private static void PrintProblems(int numberOfProject)
        {
            Console.WriteLine("Список задач:");
            Console.WriteLine(Project.projects[numberOfProject].PrintProblems());
            Console.WriteLine("Для перехода к меню проекта нажмите любую клавишу");
            Console.ReadLine();
        }

        /// <summary>
        /// Метод, осуществляющий работу с задачами типа Epic.
        /// </summary>
        /// <param name="numberOfProject"> Номер выбранного проекта. </param>
        /// <param name="numberOfProblem"> Номер выбранной задачи. </param>
        static void WorkWithEpic(int numberOfProject, int numberOfProblem)
        {
            while (true)
            {
                Clear();
                    Console.WriteLine("0. Вернуться в меню проекта" + Environment.NewLine +
                        "1. Удалить задачу" + Environment.NewLine +
                        "2. Посмотреть список подзадач"+ Environment.NewLine+
                        "3. Добавить подзадачу в Epic" + Environment.NewLine +
                        "4. Удалить подзадачу из Epic" + Environment.NewLine +
                        "5. Изменить статус задачи" + Environment.NewLine+
                        "6. Выбрать подзадачу для работы с ней");
                switch (Chose(0, 6))
                {
                    case 0:
                        return;
                    case 1:
                        DeleteProblem(numberOfProject, numberOfProblem);
                        return;
                    case 2:
                        PrintProblemsInEpic(numberOfProject, numberOfProblem);
                        break;
                    case 3:
                        Console.WriteLine("Введите название задачи");
                        string nameOfProblem = Console.ReadLine();
                    NonCorrectType:
                        Console.Write("Введите тип задачи: ");
                        DateTime dateOfCreat = DateTime.Now;
                        switch (Console.ReadLine())
                        {
                            case "Task":
                                if (((Epic)Project.projects[numberOfProject].problems[numberOfProblem]).AddProblem(new Task(nameOfProblem, dateOfCreat)))
                                {
                                    Console.WriteLine("Задача добавлена");
                                    break;
                                }
                                Console.WriteLine("Достигнуто максимальное число задач");
                                break;
                            case "Story":
                                if (((Epic)Project.projects[numberOfProject].problems[numberOfProblem]).AddProblem(new Story(nameOfProblem, dateOfCreat)))
                                {
                                    Console.WriteLine("Задача добавлена");
                                    break;
                                }
                                Console.WriteLine("Достигнуто максимальное число задач");
                                break;
                            default:
                                Console.WriteLine("Некорректный тип");
                                goto NonCorrectType;
                        }
                        Console.WriteLine("Для перехода к меню проекта нажмите любую клавишу");
                        Console.ReadLine();
                        break;
                    case 4:
                        if (((Epic)Project.projects[numberOfProject].problems[numberOfProblem]).problems.Count == 0)
                        {
                            Console.WriteLine("Не создано ни одной подзадачи");
                            Console.WriteLine("Для возврата введите любую строку");
                            Console.ReadLine();
                            break;
                        }
                        Console.WriteLine("Выберите какую подзадачу вы хотите удалить");
                        Console.WriteLine(((Epic)Project.projects[numberOfProject].problems[numberOfProblem]).PrintProblems());
                        ((Epic)Project.projects[numberOfProject].problems[numberOfProblem]).RemoveProblem(Chose(1, ((Epic)Project.projects[numberOfProject].problems[numberOfProblem]).problems.Count) - 1);
                    
                        Console.WriteLine("Подзадача удалена, для перехода в меню проекта введите любую строку");
                        Console.ReadLine();
                        break;
                    case 5:
                        Console.WriteLine("Введите новый статус");
                        string status = Console.ReadLine().ToLower();
                        if (status == "открытая задача" || status == "задача в работе" || status == "завершенная задача")
                        {
                            Project.projects[numberOfProject].problems[numberOfProblem].status = status;
                            Console.WriteLine("Статус изменен");
                            Console.WriteLine("Для возврата введите любую строку или просто нажмите Enter");
                            Console.ReadLine();
                        }
                        else
                        {
                            Console.WriteLine("Статус некорректен");
                            Console.WriteLine("Для возврата введите любую строку или просто нажмите Enter");
                            Console.ReadLine();
                        }
                        break;
                    case 6:
                        if (((Epic)Project.projects[numberOfProject].problems[numberOfProblem]).problems.Count == 0)
                        {
                            Console.WriteLine("Не создано ни одной подзадачи");
                            Console.WriteLine("Для возврата введите любую строку");
                            Console.ReadLine();
                            break;
                        }
                        Console.WriteLine("Выберите какую подзадачу");
                        Console.WriteLine(((Epic)Project.projects[numberOfProject].problems[numberOfProblem]).PrintProblems());
                        int numberOfProblemInEpic = Chose(1, ((Epic)Project.projects[numberOfProject].problems[numberOfProblem]).problems.Count) - 1;
                        WorkWithSelectProblemOfEpic(numberOfProject, numberOfProblem, numberOfProblemInEpic);
                        break;
                }
            }
            
        }


        /// <summary>
        /// Метод, осуществляющий вывод на консоль списка задач выбранной задачи типа Epic.
        /// </summary>
        /// <param name="numberOfProject"> Номер выбранного проекта. </param>
        /// <param name="numberOfProblem"> Номер выбранной задачи. </param>
        private static void PrintProblemsInEpic(int numberOfProject, int numberOfProblem)
        {
            if (((Epic)Project.projects[numberOfProject].problems[numberOfProblem]).problems.Count == 0)
            {
                Console.WriteLine("Не создано ни одной подзадачи");
            }
            else
            {
                Console.WriteLine(((Epic)Project.projects[numberOfProject].problems[numberOfProblem]).PrintProblems());
            }

            Console.WriteLine("Для возврата введите любую строку");
            Console.ReadLine();
        }

        /// <summary>
        /// Метод, осуществляющий удаление задачи.
        /// </summary>
        /// <param name="numberOfProject"> Номер выбранного проекта. </param>
        /// <param name="numberOfProblem"> Номер выбранной задачи. </param>
        private static void DeleteProblem(int numberOfProject, int numberOfProblem)
        {
            Project.projects[numberOfProject].problems.RemoveAt(numberOfProblem);
            Console.WriteLine("Задача удалена, для перехода в меню проекта введите любую строку");
            Console.ReadLine();
        }


        /// <summary>
        /// Работа с подзадачей  задачи типа Epic
        /// </summary>
        /// <param name="numberOfProject"> Номер выбранного проекта. </param>
        /// <param name="numberOfProblem"> Номер Epic задачи. </param>
        /// <param name="numberOfProblemInEpic"> Номер подзадачи </param>
        static void WorkWithSelectProblemOfEpic(int numberOfProject, int numberOfProblem, int numberOfProblemInEpic)
        {
            while (true)
            {
                Clear();
                Console.WriteLine("0. Вернуться в меню Epic" + Environment.NewLine +
                    "1. Добавить исполнителя задачи" + Environment.NewLine +
                    "2. Удалить исполнителя задачи" + Environment.NewLine +
                    "3. Изменить исполнителя задачи" + Environment.NewLine +
                    "4. Изменить статус задачи");
                switch (Chose(0, 6))
                {
                    case 0:
                        return;
                    case 1:
                        if (User.users.Count == 0)
                        {
                            Console.WriteLine("Не создано ни одного пользователя");
                            Console.WriteLine("Для возврата введите любую строку или просто нажмите Enter");
                            Console.ReadLine();
                            break;
                        }
                        Console.WriteLine(User.PrintUsers());
                        Console.WriteLine("Выберите исполнителя");
                        if (((Epic)Project.projects[numberOfProject].problems[numberOfProblem]).problems[numberOfProblemInEpic].AppendUser(User.users[Chose(1, User.users.Count) - 1]))
                        {
                            Console.WriteLine("Исполнитель добавлен, для возврата введите любую строку или просто нажмите Enter");
                            Console.ReadLine();
                        }
                        else
                        {
                            Console.WriteLine("Либо привышен лимит исполнителей, либо такой исполнитель уже есть");
                            Console.WriteLine("Для возврата введите любую строку или просто нажмите Enter");
                            Console.ReadLine();
                        }
                        break;
                    case 2:
                        if (((Epic)Project.projects[numberOfProject].problems[numberOfProblem]).problems[numberOfProblemInEpic].Users.Count == 0)
                        {
                            Console.WriteLine("Не добавлено ни одного исполнителя в задачу");
                            Console.WriteLine("Для возврата введите любую строку или просто нажмите Enter");
                            Console.ReadLine();
                            break;
                        }
                        Console.WriteLine(((Epic)Project.projects[numberOfProject].problems[numberOfProblem]).problems[numberOfProblemInEpic].PrintUsersOfProblem());
                        ((Epic)Project.projects[numberOfProject].problems[numberOfProblem]).problems[numberOfProblemInEpic].DeleteUser
                            (Chose(1, ((Epic)Project.projects[numberOfProject].problems[numberOfProblem]).problems[numberOfProblemInEpic].Users.Count) - 1);
                        Console.WriteLine("Пользователь удален");
                        Console.WriteLine("Для возврата введите любую строку или просто нажмите Enter");
                        Console.ReadLine();
                        break;
                    case 3:
                        if (User.users.Count == 0)
                        {
                            Console.WriteLine("Не создано ни одного пользователя");
                            Console.WriteLine("Для возврата введите любую строку или просто нажмите Enter");
                            Console.ReadLine();
                            break;
                        }
                        if (((Epic)Project.projects[numberOfProject].problems[numberOfProblem]).problems[numberOfProblemInEpic].Users.Count == 0)
                        {
                            Console.WriteLine("Нет ни одного пользователя у задачи (менять некого)");
                            Console.WriteLine("Для возврата введите любую строку или просто нажмите Enter");
                            Console.ReadLine();
                            break;
                        }
                        Console.WriteLine("Выберите исполнителя, которого вы хотите заменить");
                        Console.WriteLine(((Epic)Project.projects[numberOfProject].problems[numberOfProblem]).problems[numberOfProblemInEpic].PrintUsersOfProblem());
                        int numberOfUser = Chose(1, ((Epic)Project.projects[numberOfProject].problems[numberOfProblem]).problems[numberOfProblemInEpic].Users.Count) - 1;
                        Console.WriteLine("Выберите нового исполнителя");
                        Console.WriteLine(User.PrintUsers());
                        int numberOfNewUser = Chose(1, User.users.Count) - 1;
                        if (((Epic)Project.projects[numberOfProject].problems[numberOfProblem]).problems[numberOfProblemInEpic].ChangeUser(numberOfUser, User.users[numberOfNewUser]))
                        {
                            Console.WriteLine("Исполнитель изменен");
                            Console.WriteLine("Для возврата введите любую строку или просто нажмите Enter");
                            Console.ReadLine();
                        }
                        else
                        {
                            Console.WriteLine("Такой исполнитель уже есть, не удалось провести замену");
                            Console.WriteLine("Для возврата введите любую строку или просто нажмите Enter");
                            Console.ReadLine();
                        }
                        break;
                    case 4:
                        Console.WriteLine("Введите новый статус");
                        string status = Console.ReadLine().ToLower();
                        if (status == "открытая задача" || status == "задача в работе" || status == "завершенная задача")
                        {
                            ((Epic)Project.projects[numberOfProject].problems[numberOfProblem]).problems[numberOfProblemInEpic].status = status;
                            Console.WriteLine("Статус изменен");
                            Console.WriteLine("Для возврата введите любую строку или просто нажмите Enter");
                            Console.ReadLine();
                        }
                        else
                        {
                            Console.WriteLine("Некорректный статус");
                            Console.WriteLine("Для возврата введите любую строку или просто нажмите Enter");
                            Console.ReadLine();
                        }
                        break;
                }
            }

        }

        /// <summary>
        /// Работа с выбранной задачей.
        /// </summary>
        /// <param name="numberOfProject"> Номер выбранного проекта. </param>
        /// <param name="numberOfProblem"> Номер выбранной задачи. </param>
        static void WorkWithSelectProblem(int numberOfProject, int numberOfProblem)
        {
            while (true)
            {
                Clear();
                Console.WriteLine("0. Вернуться в меню проекта" + Environment.NewLine +
                    "1. Удалить задачу" + Environment.NewLine +
                    "2. Добавить исполнителя задачи" + Environment.NewLine +
                    "3. Удалить исполнителя задачи" + Environment.NewLine +
                    "4. Изменить исполнителя задачи" + Environment.NewLine +
                    "5. Изменить статус задачи");
                switch (Chose(0, 6))
                {
                    case 0:
                        return;
                    case 1:
                        Project.projects[numberOfProject].problems.RemoveAt(numberOfProblem);
                        Console.WriteLine("Задача удалена, для перехода в меню проекта введите любую строку");
                        Console.ReadLine();
                        return;
                    case 2:
                        if (User.users.Count == 0)
                        {
                            Console.WriteLine("Не создано ни одного пользователя");
                            Console.WriteLine("Для возврата введите любую строку или просто нажмите Enter");
                            Console.ReadLine();
                            break;
                        }
                        Console.WriteLine(User.PrintUsers()  );
                        Console.WriteLine("Выберите исполнителя");
                        if (Project.projects[numberOfProject].problems[numberOfProblem].AppendUser(User.users[Chose(1, User.users.Count) - 1]))
                        {
                            Console.WriteLine("Исполнитель добавлен, для возврата введите любую строку или просто нажмите Enter");
                            Console.ReadLine();
                        }
                        else
                        {
                            Console.WriteLine("Либо привышен лимит исполнителей, либо такой исполнитель уже есть");
                            Console.WriteLine("Для возврата введите любую строку или просто нажмите Enter");
                            Console.ReadLine();
                        }
                        break;
                    case 3:
                        if (Project.projects[numberOfProject].problems[numberOfProblem].Users.Count == 0)
                        {
                            Console.WriteLine("Не добавлено ни одного исполнителя в задачу");
                            Console.WriteLine("Для возврата введите любую строку или просто нажмите Enter");
                            Console.ReadLine();
                            break;
                        }
                        Console.WriteLine(Project.projects[numberOfProject].problems[numberOfProblem].PrintUsersOfProblem());
                        Project.projects[numberOfProject].problems[numberOfProblem].DeleteUser
                            (Chose(1, Project.projects[numberOfProject].problems[numberOfProblem].Users.Count) - 1);
                        Console.WriteLine("Пользователь удален");
                        Console.WriteLine("Для возврата введите любую строку или просто нажмите Enter");
                        Console.ReadLine();
                        break;
                    case 4:
                        if (User.users.Count == 0)
                        {
                            Console.WriteLine("Не создано ни одного пользователя");
                            Console.WriteLine("Для возврата введите любую строку или просто нажмите Enter");
                            Console.ReadLine();
                            break;
                        }
                        if (Project.projects[numberOfProject].problems[numberOfProblem].Users.Count == 0)
                        {
                            Console.WriteLine("Нет ни одного пользователя у задачи (менять некого)");
                            Console.WriteLine("Для возврата введите любую строку или просто нажмите Enter");
                            Console.ReadLine();
                            break;
                        }
                        Console.WriteLine( "Выберите исполнителя, которого вы хотите заменить");
                        Console.WriteLine(Project.projects[numberOfProject].problems[numberOfProblem].PrintUsersOfProblem());
                        int numberOfUser=Chose(1, Project.projects[numberOfProject].problems[numberOfProblem].Users.Count)-1;
                        Console.WriteLine("Выберите нового исполнителя");
                        Console.WriteLine(User.PrintUsers());
                        int numberOfNewUser = Chose(1, User.users.Count) - 1;
                        if (Project.projects[numberOfProject].problems[numberOfProblem].ChangeUser(numberOfUser, User.users[numberOfNewUser]))
                        {
                            Console.WriteLine("Исполнитель изменен");
                            Console.WriteLine("Для возврата введите любую строку или просто нажмите Enter");
                            Console.ReadLine();
                        }
                        else
                        {
                            Console.WriteLine("Такой исполнитель уже есть, не удалось провести замену");
                            Console.WriteLine("Для возврата введите любую строку или просто нажмите Enter");
                            Console.ReadLine();
                        }
                        break;
                    case 5:
                        Console.WriteLine("Введите новый статус");
                        string status = Console.ReadLine().ToLower();
                        if (status=="открытая задача" || status == "задача в работе" || status== "завершенная задача")
                        {
                            Project.projects[numberOfProject].problems[numberOfProblem].status = status;
                            Console.WriteLine("Статус изменен");
                            Console.WriteLine("Для возврата введите любую строку или просто нажмите Enter");
                            Console.ReadLine();
                        }
                        else
                        {
                            Console.WriteLine("Некорректный статус");
                            Console.WriteLine("Для возврата введите любую строку или просто нажмите Enter");
                            Console.ReadLine();
                        }
                        break;
                }
            }
            
        }

        /// <summary>
        /// Метод, осуществляющий очистку консоли.
        /// </summary>
        static void Clear()
        {
            try
            {
                Console.Clear();
            }
            catch
            {

            }
        }

        /// <summary>
        ///  Метод, осуществляющий работу с пользователями.
        /// </summary>
        static void WorkWithUsers()
        {
            Clear();
            Console.WriteLine("Выберите один из вариантов:" + Environment.NewLine +
                "1. Просмотр списка пользователей" + Environment.NewLine +
                "2. Создание пользователя" + Environment.NewLine +
                "3. Удаление пользователя");
            switch (Chose(1, 3))
            {
                case 1:
                    Console.WriteLine(User.PrintUsers());
                    Console.WriteLine("Для возвращения в меню нажмите любую клавишу");
                    Console.ReadLine();
                    break;
                case 2:
                    Console.WriteLine("Введите имя пользователя");
                    string userName = Console.ReadLine();
                    User newUser= new User(userName);
                    if (User.AddUser(newUser))
                    {
                        Console.WriteLine("Пользователь добавлен, для возвращения в меню нажмите любую клавишу");
                    }
                    else
                    {
                        Console.WriteLine("Такой пользователь уже существует, для возвращения в меню нажмите любую клавишу");
                    }
                    Console.ReadLine();
                    break;
                case 3:
                    if (User.users.Count > 0)
                    {
                        Console.WriteLine("Выберите кого вы хотите удалить");
                        Console.WriteLine(User.PrintUsers());
                        User.DeleteUser(Chose(1, User.users.Count)-1);
                        Console.WriteLine("Пользователь удален, для возвращения в меню нажмите любую клавишу");
                        Console.ReadLine();
                    }
                    else
                    {
                        Console.WriteLine("Нет ни одного пользователя");
                        Console.WriteLine("Для возвращения в меню нажмите любую клавишу");
                        Console.ReadLine();
                    }
                     break;
            }
        }


        /// <summary>
        /// Метод, вынуждающий ввести пользователя число из заданного диапазона.
        /// </summary>
        /// <param name="minimum"> Нижняя грань диапазана. </param>
        /// <param name="maximum"> Верхняя грань диапазона. </param>
        /// <returns></returns>
        static int Chose(int minimum, int maximum)
        {
            string input=Console.ReadLine();
            if (int.TryParse(input, out int result) && result>=minimum && result<=maximum)
            {
                return result;
            }
            Console.WriteLine("Некорректный ввод, попробуйте еще раз");
            return Chose(minimum, maximum);
        }
    }
}
