﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace ClassLibrary1
{



    /// <summary>
    /// Класс проектов.
    /// </summary>
    [Serializable]
    [XmlInclude (typeof(Task))]
    [XmlInclude(typeof(Epic))]
    [XmlInclude(typeof(Bug))]
    [XmlInclude(typeof(Story))]
    public class Project
    {
        public Project()
        {

        }
        public static List<Project> projects = new List<Project>();
        public string name;
        public List<Problem> problems= new List<Problem>();
        const int maxNumberOfProblems = 10;

        public Project(string name)
        {
            this.name = name;
            projects.Add(this);
        }

        /// <summary>
        /// Метод нужный для добавления задачи.
        /// </summary>
        /// <param name="newProblem"> Задача, которую нужно добавить.</param>
        /// <returns></returns>
        public bool AddProblem(Problem newProblem)
        {
            if (problems.Count < maxNumberOfProblems)
            {
                problems.Add(newProblem);
                return true;
            }
            return false;
        }

        /// <summary>
        /// Метод, нужный для вывода списка задач на экран.
        /// </summary>
        /// <returns></returns>
        public string PrintProblems()
        {
            string result = "";
            int j = 1;
            foreach (Problem i in problems)
            {
                result += '\t'  + j.ToString()+". "+ i.ToString();
                j++;
            }
            return result;
        }

        /// <summary>
        /// Метод для удаление проекта.
        /// </summary>
        /// <param name="projectNumber"> Номер проекта в списке проектов.</param>
        public static void DeleteProject(int projectNumber)
        {
            projects.RemoveAt(projectNumber);
        }

        public override string ToString()
        {
            return $"{this.name} Количество задач: {this.problems.Count}";
        }


        /// <summary>
        /// Метод нужный для вывода списка всех проектов на экран.
        /// </summary>
        /// <returns></returns>
        public static string PrintProjects()
        {
            string result = "";
            result+="Список проектов:"+Environment.NewLine;
            int j = 1;
            foreach (Project i in projects)
            {
                result+=$"    {j++}. {i.name}" + Environment.NewLine;
                result += "        Количество задач: " + i.problems.Count+ Environment.NewLine;
            }
            return result;
        }

        /// <summary>
        /// Метод, осуществляющий группировку задач по статусу.
        /// </summary>
        public void Groupping()
        {
            problems = (from p in problems orderby p.status[2] select p).ToList();
        }
    }
}
