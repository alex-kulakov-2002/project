﻿using System.Collections.Generic;

namespace ClassLibrary1
{
    /// <summary>
    /// Класс, используемый для сериализации пользователей.
    /// </summary>
    public class Users
    {
        public List<User> users;
    }
}
