﻿using System;
using System.Collections.Generic;

namespace ClassLibrary1
{
    /// <summary>
    /// Наследник класса задач.
    /// </summary>
    [Serializable]
    public class Epic : Problem
    {

        public Epic()
        {

        }
        public Epic(string name, DateTime dateOfCreat, string status = "Открытая задача") :base(name, dateOfCreat, status)
        {
           
        }



        const int maxNumberOfProblems = 10;

        public List<Problem> problems=new List<Problem>();

        /// <summary>
        /// Метод нужный для вывода списка подзадач на экран.
        /// </summary>
        /// <returns></returns>
        public string PrintProblems()
        {
            string result = "";
            int j = 1;
            foreach (Problem i in problems)
            {
                result += '\t' + j.ToString() + ". " + i.ToString();
                j++;
            }
            return result;
        }


        /// <summary>
        /// Метод, осуществляющий добавление подзачачи.
        /// </summary>
        /// <param name="newProblem"> Подзадача, которую нужно добавить. </param>
        /// <returns></returns>
        public bool AddProblem(Problem newProblem)
        {
            if (problems.Count < maxNumberOfProblems)
            {
                problems.Add(newProblem);
                return true;
            }

            return false;
        }

        /// <summary>
        /// Метод, осуществляющий удаление подзадачи.
        /// </summary>
        /// <param name="numberOfProblem"> Номер подзадачи, которую нужно удалить. </param>
        public void RemoveProblem(int numberOfProblem)
        {
            problems.RemoveAt(numberOfProblem);
        }

    }
}
