﻿using System;
using System.Collections.Generic;

namespace ClassLibrary1
{
    /// <summary>
    /// Класс задач.
    /// </summary>
    [Serializable]
    public abstract class Problem
    {
        public Problem()
        {

        }
        public string name;
        public DateTime dateOfCreat;
        public string status;

        private List<User> users = new List<User>();
        public List<User> Users
        {
            get
            {
                return users;
            }
            set
            {
                users = value;
            }
        }

        /// <summary>
        /// Метод нужный для вывода списка исполнителей на экран.
        /// </summary>
        /// <returns></returns>
        public string PrintUsersOfProblem()
        {
            string result = "Список исполнителей:" + Environment.NewLine;
            int j = 1;
            foreach (User i in Users)
            {
                result += "    " + j.ToString() + '.' + i.Name + Environment.NewLine;
                j++;
            }
            return result;
        }



        public Problem(string name, DateTime dateOfCreat, string status="Открытая задача")
        {
            this.name = name;
            this.dateOfCreat = dateOfCreat;
            this.status = status;
        }

        public virtual bool AppendUser(User user)
        {
            return true;
        }

        public virtual  void DeleteUser(int numberOfUser)
        {

        }
        public virtual  bool ChangeUser(int numberOfUser, User user)
        {
            return true;
        }



        public override string ToString()
        {
            string result = "";
            result += name+Environment.NewLine;
            result += "\t\t" + "Тип: " + this.GetType().ToString().Split('.')[1] + Environment.NewLine;
            result += "\t\t"  + "Статус: " + status + Environment.NewLine;
            result += "\t\t" + "Дата создания: " + dateOfCreat + Environment.NewLine;
            result += "\t\t"  + "Спиок исполнителей:" + Environment.NewLine;
            int j = 1;
            if (Users==null || Users.Count == 0)
            {
                result += "\t\t\t" + "У этой задачи нет исполнителей"+Environment.NewLine;
                return result;
            }
            else
            {
                foreach (User i in Users)
                {
                    result += "\t\t\t" + j + ". " + i.Name+ Environment.NewLine;
                    j++;
                }
            }

            return result;
        }
    }
}
