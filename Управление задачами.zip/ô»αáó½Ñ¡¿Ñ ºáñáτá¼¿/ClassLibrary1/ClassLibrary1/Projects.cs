﻿using System.Collections.Generic;

namespace ClassLibrary1
{
    /// <summary>
    /// Класс, используемый для сериализации проектов.
    /// </summary>
    public class Projects
    {
        public List<Project> projects;
    }
}
