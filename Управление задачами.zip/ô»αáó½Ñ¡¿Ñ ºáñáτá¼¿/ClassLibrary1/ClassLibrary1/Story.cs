﻿using System;

namespace ClassLibrary1
{
    /// <summary>
    /// Наследник класса задач.
    /// </summary>
    [Serializable]
    public class Story : Problem, IAssignable
    {

        public Story()
        {

        }
        const int maxNumberOfUsers = 10;
        public Story(string name, DateTime dateOfCreat, string status = "Открытая задача") : base(name, dateOfCreat, status)
        {

        }


        /// <summary>
        /// Метод, осуществляющий добавление исполнителя.
        /// </summary>
        /// <param name="user"> Исполнитель, которого нужно добавить. </param>
        /// <returns></returns>
        public override bool AppendUser( User user)
        {
            if (Users.Count >= 10)
            {
                return false;
            }
            foreach (User i in Users)
            {
                if (i.Name == user.Name) return false;
            }
            Users.Add(user);
            return true;
        }

        /// <summary>
        /// Метод, осуществляющий удаление исполнителя.
        /// </summary>
        /// <param name="numberOfUser"> Номер исполнителя, которого нужно удалить. </param>
        public override void DeleteUser(int numberOfUser)
        {
            Users.RemoveAt(numberOfUser);
        }

        /// <summary>
        /// Метод, осуществляющий замену исполнителя.
        /// </summary>
        /// <param name="numberOfUser"> Номер исполнителя, которого нужно заменить.</param>
        /// <param name="user"> Исполнитель, на которого надо заменить. </param>
        /// <returns></returns>
        public override bool ChangeUser(int numberOfUser, User user)
        {
            for (int i=0; i < Users.Count; i++)
            {
                if (i == numberOfUser) continue;
                if (Users[i].Name == user.Name) return false; 
            }
            Users[numberOfUser] = user;
            return true;
        }


    }
}
