﻿using System;
using System.Collections.Generic;

namespace ClassLibrary1
{
    /// <summary>
    /// Интерфейс.
    /// </summary>
    public interface IAssignable
    {
        public  List<User> Users { get; set; }
        public bool AppendUser(User user);

        public void DeleteUser(int numberOfUser);
        public bool ChangeUser(int numberOfUser, User user);

        public string PrintUsersOfProblem()
        {
            string result = "Список исполнителей:" + Environment.NewLine;
            int j = 1;
            foreach (User i in Users)
            {
                result += "    " + j.ToString() + '.' + i.Name + Environment.NewLine;
                j++;
            }
            return result;
        }
    }
}
