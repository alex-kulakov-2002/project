﻿using System;
using System.Collections.Generic;

namespace ClassLibrary1
{
    /// <summary>
    /// Класс пользователей.
    /// </summary>
    [Serializable]
    public class User
    {
        public User()
        {

        }

        public static List<User> users = new List<User>();
        public string Name { get; set; }

        public User(string name)
        {
            Name = name;
        }

        /// <summary>
        /// Метод, осуществляющий удаление пользователя.
        /// </summary>
        /// <param name="userNumber"> Номер пользователя, которого нужно удалить.</param>
        public static void  DeleteUser(int userNumber)
        {
            int inumber=-1;
            foreach( Project i in Project.projects)
            {
                inumber++;
                int jnumber = -1;
                foreach (Problem j in i.problems)
                {
                    jnumber++;
                    if (j.GetType().ToString().Split('.')[1] == "Epic")
                    {
                        Epic task = (Epic)j;
                        int lnumber = -1;
                        foreach (Problem l in task.problems)
                        {
                            lnumber++;
                            int numberOfUser = -1;
                            int result = -1;
                            foreach (User z in j.Users)
                            {
                                numberOfUser += 1;
                                if (z.Name == User.users[userNumber].Name)
                                {
                                    result = numberOfUser;
                                }
                            }
                            if (result != -1) ((Epic)Project.projects[inumber].problems[jnumber]).problems[lnumber].DeleteUser(result);
                        }
                        
                    }
                    else
                    {

                        int numberOfUser = -1;
                        int result = -1;
                        foreach (User z in j.Users)
                        {
                            numberOfUser += 1;
                            if (z.Name == User.users[userNumber].Name)
                            {
                                result = numberOfUser;
                            }
                        }
                        if (result != -1) Project.projects[inumber].problems[jnumber].DeleteUser(result);
                    }
                }
            }
            users.RemoveAt(userNumber);
        }

        /// <summary>
        /// Метод, осуществляющий добавление пользователя.
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public static bool AddUser(User user)
        {
            foreach (User i in users)
            {
                if (i.Name == user.Name)
                {
                    return false;
                }
            }
            users.Add(user);
            return true;
        }

        /// <summary>
        /// Метод нужный для вывода списка пользователей на экран.
        /// </summary>
        /// <returns></returns>
        public static string PrintUsers()
        {
            string result="";
            result += "Список пользователей:"+ Environment.NewLine;
            int j = 1;
            foreach (User i in users)
            {
                result+=$"    {j++}. {i.Name}"+ Environment.NewLine;
            }
            return result;
        }
    }
}
